
import { 
  Bar, Campaign, Customer, SalesTransaction, SalesImportBatch, 
  User, UserRole, DashboardStats, ChartDataPoint,
  SalesVelocity, AiActionItem, SegmentStat, HeatmapPoint, StaffStat, InventoryItem,
  WebsiteStats, SalesForecast, HourlyComparison
} from '../types';

// --- HELPERS ---
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const normalizePhone = (phone: string) => phone.replace(/\D/g, '');

const calculateTier = (spent: number, visits: number): 'VIP' | 'Regular' | 'New' => {
  if (spent > 500 || visits > 10) return 'VIP';
  if (visits > 1) return 'Regular';
  return 'New';
};

// --- MOCK DATA STORE ---
const MOCK_BARS: Bar[] = [
  {
    id: 'b1',
    businessName: 'The Rusty Anchor',
    ownerName: 'Sam Malone',
    email: 'sam@rustyanchor.com',
    phone: '555-0101',
    address: '123 Harbor Blvd',
    slug: 'rusty-anchor',
    isActive: true,
    customerCount: 4,
    campaignCount: 2,
  }
];

// Initial customers
let MOCK_CUSTOMERS: Customer[] = [
  {
    id: 'c1',
    barId: 'b1',
    firstName: 'John',
    lastName: 'Doe',
    email: 'john@example.com',
    phone: '5551234567',
    birthday: '1990-05-15',
    is21Plus: true,
    optInSms: true,
    optInEmail: true,
    signupDate: '2023-10-01T10:00:00Z',
    totalSpent: 450.50,
    totalVisits: 12,
    lastVisitDate: '2023-10-25T19:00:00Z',
    customerTier: 'Regular',
    tags: ['beer-lover']
  },
  {
    id: 'c2',
    barId: 'b1',
    firstName: 'Jane',
    lastName: 'Smith',
    email: 'jane@example.com',
    phone: '5559876543',
    birthday: '1992-08-22',
    is21Plus: true,
    optInSms: true,
    optInEmail: false,
    signupDate: '2023-10-05T14:30:00Z',
    totalSpent: 85.00,
    totalVisits: 2,
    lastVisitDate: '2023-10-10T20:30:00Z',
    customerTier: 'Regular',
    tags: []
  },
  {
    id: 'c3',
    barId: 'b1',
    firstName: 'Mike',
    lastName: 'Vip',
    phone: '5557778888',
    birthday: '1985-01-10',
    is21Plus: true,
    optInSms: true,
    optInEmail: true,
    signupDate: '2023-01-15T09:00:00Z',
    totalSpent: 1200.00,
    totalVisits: 45,
    lastVisitDate: '2023-10-28T18:00:00Z',
    customerTier: 'VIP',
    tags: ['high-roller']
  }
];

let MOCK_SALES: SalesTransaction[] = [];
let MOCK_BATCHES: SalesImportBatch[] = [];
let MOCK_CAMPAIGNS: Campaign[] = [
  {
    id: 'cmp1',
    barId: 'b1',
    name: 'Friday Happy Hour',
    type: 'sms',
    message: 'Join us for 50% off drafts this Friday!',
    status: 'sent',
    sentAt: '2023-10-27T16:00:00Z',
    recipientCount: 1200,
    successCount: 1150,
    failureCount: 50,
    revenueBefore: 2500,
    revenueAfter: 4200
  }
];

const MOCK_BAR_PREFS: Record<string, { birthdayTemplate: string }> = {
  'b1': { birthdayTemplate: "Happy Birthday! Show this for a free drink." }
};

export const mockService = {
  // --- AUTH ---
  login: async (email: string): Promise<User | null> => {
    await delay(500);
    if (email === 'admin@barboost.com') return { id: 'admin1', email, role: UserRole.SUPER_ADMIN };
    const bar = MOCK_BARS.find(b => b.email === email);
    if (bar) return { id: bar.id, email, role: UserRole.BAR_OWNER, barId: bar.id };
    return null;
  },

  // --- CUSTOMERS ---
  getCustomers: async (barId: string): Promise<Customer[]> => {
    await delay(300);
    return MOCK_CUSTOMERS.filter(c => c.barId === barId);
  },

  getCustomerDetails: async (barId: string, customerId: string) => {
    await delay(300);
    const customer = MOCK_CUSTOMERS.find(c => c.id === customerId && c.barId === barId);
    const sales = MOCK_SALES.filter(s => s.customerId === customerId);
    return customer ? { customer, sales } : null;
  },

  createCustomer: async (data: any): Promise<Customer> => {
    await delay(500);
    const newC: Customer = {
      ...data,
      id: `c${Date.now()}`,
      signupDate: new Date().toISOString(),
      totalSpent: 0,
      totalVisits: 0,
      lastVisitDate: null,
      customerTier: 'New',
      tags: []
    };
    MOCK_CUSTOMERS.push(newC);
    return newC;
  },

  // --- SALES IMPORT & MATCHING ENGINE ---
  uploadSalesCsv: async (barId: string, file: File): Promise<SalesImportBatch> => {
    await delay(1500); // Simulate parsing
    
    // Simulate raw rows derived from CSV
    const simulatedRows = [
      { date: '2023-11-01', amount: 55.00, phone: '555-123-4567', items: 'Burger, Beer' }, // Matches John
      { date: '2023-11-02', amount: 120.00, phone: '555-777-8888', items: 'Champagne' }, // Matches Mike
      { date: '2023-11-03', amount: 32.50, phone: '555-000-0000', items: 'Nachos' }, // No match
      { date: '2023-11-03', amount: 45.00, email: 'john@example.com', items: 'Wings' }, // Matches John via email
      { date: '2023-11-04', amount: 15.00, phone: '555-987-6543', items: 'Cocktail' }, // Matches Jane
    ];

    const batchId = `batch-${Date.now()}`;
    let matchedCount = 0;
    let totalRevenue = 0;

    // Process rows
    simulatedRows.forEach(row => {
      const normalizedRowPhone = row.phone ? normalizePhone(row.phone) : '';
      
      // Attempt Matching
      let match = MOCK_CUSTOMERS.find(c => 
        (row.phone && normalizePhone(c.phone) === normalizedRowPhone) ||
        (row.email && c.email === row.email)
      );

      const isMatched = !!match;
      if (isMatched) matchedCount++;
      totalRevenue += row.amount;

      // Create Transaction
      const transaction: SalesTransaction = {
        id: `txn-${Math.random()}`,
        barId,
        customerId: match ? match.id : null,
        transactionDate: new Date(row.date).toISOString(),
        amount: row.amount,
        items: row.items,
        phone: row.phone,
        email: row.email,
        isMatched,
        importBatchId: batchId
      };
      MOCK_SALES.push(transaction);

      // Update Customer Stats if matched
      if (match) {
        match.totalSpent += row.amount;
        match.totalVisits += 1;
        match.lastVisitDate = new Date(row.date).toISOString();
        match.customerTier = calculateTier(match.totalSpent, match.totalVisits);
      }
    });

    const batch: SalesImportBatch = {
      id: batchId,
      barId,
      filename: file.name,
      totalRows: simulatedRows.length,
      matchedRows: matchedCount,
      unmatchedRows: simulatedRows.length - matchedCount,
      totalRevenue,
      importDate: new Date().toISOString(),
      status: 'completed'
    };

    MOCK_BATCHES.unshift(batch);
    return batch;
  },

  getImportBatches: async (barId: string): Promise<SalesImportBatch[]> => {
    await delay(300);
    return MOCK_BATCHES.filter(b => b.barId === barId);
  },

  // --- ANALYTICS & DASHBOARD ---
  getDashboardStats: async (barId: string): Promise<DashboardStats> => {
    await delay(400);
    const customers = MOCK_CUSTOMERS.filter(c => c.barId === barId);
    
    // Calculate total revenue from ALL sales (matched and unmatched)
    const revenue = MOCK_SALES.filter(s => s.barId === barId).reduce((sum, s) => sum + s.amount, 0) + 15400; // + base mock revenue

    const totalCust = customers.length;
    
    return {
      totalCustomers: totalCust,
      customerGrowth: 12.5,
      newCustomers: customers.filter(c => new Date(c.signupDate) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)).length,
      newCustomersGrowth: 5.2,
      totalRevenue: revenue,
      revenueGrowth: 8.4,
      avgCustomerValue: totalCust ? (revenue / totalCust) : 0,
      avgValueGrowth: 2.1
    };
  },

  getSalesVelocity: async (barId: string): Promise<SalesVelocity> => {
    await delay(300);
    return {
      wtd: 12450,
      wtdGrowth: 12,
      mtd: 38200,
      mtdGrowth: 8,
      ytd: 340500,
      ytdGrowth: 15,
      pacePercentage: 103,
      paceStatus: 'ahead'
    };
  },

  getAiActionItems: async (barId: string): Promise<AiActionItem[]> => {
    await delay(300);
    return [
      { id: '1', type: 'high-impact', title: '8 VIP Birthdays This Week', description: 'These customers spend avg $50/visit.', revenuePotential: 400, actionLabel: 'Send Campaign' },
      { id: '2', type: 'revenue-opp', title: 'Thursday Sales Down 15%', description: 'Traffic is dipping 6-8pm.', revenuePotential: 200, actionLabel: 'Run Promo' },
      { id: '3', type: 'time-sensitive', title: 'Import Weekly Sales', description: 'Data is 3 days overdue.', actionLabel: 'Upload CSV' },
      { id: '4', type: 'quick-win', title: '23 Customers Ready for 2nd Visit', description: '60% return rate if messaged now.', revenuePotential: 1100, actionLabel: 'Send Invite' },
    ];
  },

  getSmartSegments: async (barId: string): Promise<SegmentStat[]> => {
    await delay(300);
    return [
      { id: 'vip', label: 'VIP', count: 47, wtdRevenue: 8200, status: 'healthy', trend: '3 moved to VIP' },
      { id: 'regular', label: 'Regulars', count: 234, wtdRevenue: 3100, status: 'healthy' },
      { id: 'new', label: 'New', count: 28, wtdRevenue: 890, status: 'neutral' },
      { id: 'risk', label: 'At Risk', count: 23, wtdRevenue: 0, status: 'risk', trend: 'Lost $1,500 LTV' },
    ];
  },

  getHeatmapData: async (barId: string): Promise<HeatmapPoint[]> => {
    await delay(200);
    // Simple mock generation
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const points: HeatmapPoint[] = [];
    days.forEach(day => {
      for(let h=16; h<=23; h++) { // 4pm to 11pm
         let intensity = Math.floor(Math.random() * 50) + 20;
         if ((day === 'Fri' || day === 'Sat') && h > 18) intensity += 30; // Weekends busier
         points.push({ day, hour: h, intensity });
      }
    });
    return points;
  },

  getStaffLeaderboard: async (barId: string): Promise<StaffStat[]> => {
    await delay(200);
    return [
      { name: 'Sarah J.', role: 'Server', revenue: 4200, signups: 15 },
      { name: 'Mike T.', role: 'Bartender', revenue: 3800, signups: 8 },
      { name: 'Jessica L.', role: 'Server', revenue: 3100, signups: 12 },
    ];
  },

  getInventoryInsights: async (barId: string): Promise<InventoryItem[]> => {
    await delay(200);
    return [
      { name: 'Tito\'s Vodka', category: 'Liquor', salesVolume: 120, trend: 'up', action: 'Restock' },
      { name: 'IPA Draft', category: 'Beer', salesVolume: 85, trend: 'down', action: 'Promote' },
      { name: 'House Cab', category: 'Wine', salesVolume: 40, trend: 'up', action: 'None' },
    ];
  },

  getRevenueChartData: async (barId: string): Promise<ChartDataPoint[]> => {
    await delay(300);
    return [
      { name: 'Mon', value: 1200, value2: 1100 },
      { name: 'Tue', value: 900, value2: 1400 },
      { name: 'Wed', value: 1500, value2: 1300 },
      { name: 'Thu', value: 2100, value2: 1900 },
      { name: 'Fri', value: 4500, value2: 3800 },
      { name: 'Sat', value: 5200, value2: 4800 },
      { name: 'Sun', value: 3800, value2: 3600 },
    ];
  },

  getCustomerTierData: async (barId: string): Promise<ChartDataPoint[]> => {
    await delay(300);
    const customers = MOCK_CUSTOMERS.filter(c => c.barId === barId);
    return [
      { name: 'VIP', value: customers.filter(c => c.customerTier === 'VIP').length },
      { name: 'Regular', value: customers.filter(c => c.customerTier === 'Regular').length },
      { name: 'New', value: customers.filter(c => c.customerTier === 'New').length },
    ];
  },

  // --- WEBSITE ANALYTICS ---
  getWebsiteStats: async (barId: string): Promise<WebsiteStats> => {
    await delay(400);
    return {
      visits: 4320,
      visitsGrowth: 15.2,
      pageViews: 12500,
      bounceRate: 42.5,
      avgTimeOnSite: "2m 15s",
      topSources: [
        { source: "Google Organic", percentage: 45 },
        { source: "Direct", percentage: 25 },
        { source: "Instagram", percentage: 20 },
        { source: "Other", percentage: 10 }
      ],
      lastUpdated: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    };
  },

  // --- REAL-TIME SALES FORECASTS ---
  getSalesForecast: async (barId: string): Promise<SalesForecast> => {
    await delay(500);
    return {
      currentWeeklyPace: 12500,
      targetWeeklyPace: 11800,
      yesterdayTotal: 1840,
      yesterdayGrowth: 12,
      bestDayThisWeek: { day: 'Friday', amount: 2450 },
      avgDailyRate: 1775,
      weekendForecast: 8500,
      aiInsights: [
        "Traffic spike detected between 8PM-10PM last night compared to 3-week avg.",
        "Rain forecast for Saturday suggests 15% lower patio revenue; suggest indoor Happy Hour promo.",
        "Sales pace is 5% ahead of target, driven by strong Tuesday performance."
      ]
    };
  },

  getHourlySalesComparison: async (barId: string): Promise<HourlyComparison[]> => {
    await delay(500);
    // Mock hour-by-hour for "Today vs Avg Thursday"
    return [
      { hour: '4pm', today: 150, average: 120 },
      { hour: '5pm', today: 300, average: 280 },
      { hour: '6pm', today: 550, average: 450 },
      { hour: '7pm', today: 780, average: 600 },
      { hour: '8pm', today: 920, average: 850 },
      { hour: '9pm', today: 850, average: 900 }, // Dipping below avg
      { hour: '10pm', today: 600, average: 750 },
      { hour: '11pm', today: 400, average: 500 },
    ];
  },

  // --- CAMPAIGNS ---
  getCampaigns: async (barId: string) => {
    await delay(300);
    return MOCK_CAMPAIGNS.filter(c => c.barId === barId);
  },
  
  createCampaign: async (cmp: any) => {
    await delay(500);
    const newCmp = { ...cmp, id: `cmp-${Date.now()}`, recipientCount: 0, successCount: 0, failureCount: 0, status: 'scheduled' };
    MOCK_CAMPAIGNS.push(newCmp);
    return newCmp;
  },

  // --- BIRTHDAYS ---
  getUpcomingBirthdays: async (barId: string) => {
    await delay(300);
    // Simple mock filter
    return MOCK_CUSTOMERS.filter(c => c.barId === barId).slice(0, 2); 
  },
  
  getBirthdayTemplate: async (barId: string) => MOCK_BAR_PREFS[barId]?.birthdayTemplate || '',
  updateBirthdayTemplate: async (barId: string, msg: string) => { MOCK_BAR_PREFS[barId] = { birthdayTemplate: msg }; },
  sendBirthdayCampaign: async (barId: string, customerIds: string[], template: string) => { await delay(500); },

  // --- PUBLIC ---
  getBarBySlug: async (slug: string) => MOCK_BARS.find(b => b.slug === slug),

  // --- ADMIN ---
  getSystemStats: async () => ({
    totalBars: MOCK_BARS.length,
    totalCustomers: MOCK_CUSTOMERS.length,
    totalCampaigns: MOCK_CAMPAIGNS.length,
    activeBars: 1
  }),
  getAllBars: async () => MOCK_BARS
};

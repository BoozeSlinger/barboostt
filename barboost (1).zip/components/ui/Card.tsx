import React from 'react';

export const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => {
  // Check if a background color is provided in className to avoid conflict with default bg-white
  const hasBg = className.includes('bg-');
  const baseClasses = hasBg ? '' : 'bg-white border-slate-200';
  
  return (
    <div className={`rounded-xl shadow-sm border ${baseClasses} ${className}`}>
      {children}
    </div>
  );
};

export const CardHeader: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`p-6 border-b border-inherit ${className}`}>
    {children}
  </div>
);

export const CardTitle: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => {
  // Check if text color is provided
  const hasTextColor = className.includes('text-');
  return (
    <h3 className={`text-lg font-semibold ${hasTextColor ? '' : 'text-slate-900'} ${className}`}>{children}</h3>
  );
};

export const CardContent: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`p-6 ${className}`}>
    {children}
  </div>
);
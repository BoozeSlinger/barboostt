
import React, { useContext } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, MessageSquare, Mail, QrCode, LogOut, BarChart3, Settings, Cake, DollarSign, PieChart, Bell, Gem, Globe } from 'lucide-react';
import { AuthContext } from '../../App';
import { UserRole } from '../../types';

interface DashboardLayoutProps {
  title: string;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ title }) => {
  const { user, logout } = useContext(AuthContext);
  const location = useLocation();

  const ownerLinks = [
    { to: '/dashboard', end: true, icon: LayoutDashboard, label: 'Overview' },
    { to: '/dashboard/campaigns/sms', icon: MessageSquare, label: 'Inbox / SMS' },
    { to: '/dashboard/customers', icon: Users, label: 'Patrons' },
    { to: '/dashboard/birthdays', icon: Cake, label: 'Events' },
    { to: '/dashboard/sales', icon: DollarSign, label: 'Revenue' },
    { to: '/dashboard/website', icon: Globe, label: 'Digital Presence' },
    { to: '/dashboard/qr', icon: QrCode, label: 'Acquisition' },
    { to: '/dashboard/campaigns/email', icon: Mail, label: 'Templates' },
  ];

  const adminLinks = [
    { to: '/admin', end: true, icon: BarChart3, label: 'System Overview' },
    { to: '/admin/bars', icon: Settings, label: 'Manage Bars' },
  ];

  const links = user?.role === UserRole.SUPER_ADMIN ? adminLinks : ownerLinks;

  const getCurrentLabel = () => {
    const active = links.find(l => {
        if (l.end) return location.pathname === l.to;
        return location.pathname.startsWith(l.to);
    });
    return active ? active.label : title;
  };

  return (
    <div className="min-h-screen bg-black flex font-sans text-zinc-300 selection:bg-luxury-gold selection:text-black">
      {/* Sidebar */}
      <aside className="w-64 bg-black border-r border-zinc-900 hidden md:flex flex-col fixed inset-y-0 z-20">
        <div className="p-8 flex flex-col items-center border-b border-zinc-900/50">
          <div className="flex items-center gap-3">
             <div className="p-1.5 border border-zinc-800 rounded-sm bg-black shadow-[0_0_15px_-3px_rgba(212,175,55,0.2)]">
                <Gem className="w-5 h-5 text-luxury-gold" />
             </div>
             <div className="flex flex-col">
                <span className="font-serif text-xl text-white tracking-widest uppercase">
                  BarBoost
                </span>
             </div>
          </div>
        </div>

        <div className="flex-1 px-4 py-8 space-y-1 overflow-y-auto">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-sm text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
                  isActive
                    ? 'text-luxury-gold bg-zinc-900 border-l-2 border-luxury-gold'
                    : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-950 border-l-2 border-transparent'
                }`
              }
            >
              <link.icon className={`w-4 h-4 ${({ isActive }: any) => isActive ? 'text-luxury-gold' : 'text-zinc-600'}`} />
              {link.label}
            </NavLink>
          ))}
        </div>

        <div className="p-4 border-t border-zinc-900">
            <div className="flex items-center gap-3 px-4 py-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-luxury-gold to-yellow-200 border border-zinc-800"></div>
                <div className="overflow-hidden">
                    <p className="text-xs font-bold text-white truncate">{user?.email}</p>
                    <button onClick={logout} className="text-[10px] text-zinc-500 hover:text-luxury-gold uppercase tracking-wider flex items-center gap-1 mt-0.5">
                        <LogOut className="w-3 h-3" /> Sign Out
                    </button>
                </div>
            </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 md:ml-64 min-h-screen flex flex-col relative bg-black">
        {/* Subtle Luxury Gradient Background */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-luxury-gold/5 rounded-full blur-[100px] pointer-events-none"></div>

        <header className="h-20 flex items-center px-8 justify-between sticky top-0 z-10 backdrop-blur-xl bg-black/60 border-b border-zinc-900/50">
          <h1 className="text-2xl font-serif text-white tracking-wide">
            {getCurrentLabel()}
          </h1>
          <div className="flex items-center gap-6">
             <button className="text-zinc-500 hover:text-luxury-gold transition-colors relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-luxury-gold rounded-full"></span>
             </button>
          </div>
        </header>
        <div className="p-8 flex-1 overflow-auto relative z-0">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

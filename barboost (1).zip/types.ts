
export enum UserRole {
  SUPER_ADMIN = 'super_admin',
  BAR_OWNER = 'bar_owner',
  CUSTOMER = 'customer'
}

export interface User {
  id: string;
  email: string;
  role: UserRole;
  barId?: string;
}

export interface Bar {
  id: string;
  businessName: string;
  ownerName: string;
  email: string;
  phone: string;
  address: string;
  slug: string;
  isActive: boolean;
  customerCount: number;
  campaignCount: number;
  qrCodeUrl?: string;
}

export type CustomerTier = 'VIP' | 'Regular' | 'New';

export interface Customer {
  id: string;
  barId: string;
  firstName: string;
  lastName: string;
  email?: string;
  phone: string;
  birthday: string;
  is21Plus: boolean;
  optInSms: boolean;
  optInEmail: boolean;
  signupDate: string;
  
  // Enriched Stats
  totalVisits: number;
  totalSpent: number;
  lastVisitDate: string | null;
  customerTier: CustomerTier;
  notes?: string;
  tags: string[];
}

export interface SalesTransaction {
  id: string;
  barId: string;
  customerId?: string | null; // Null if unmatched
  transactionDate: string;
  amount: number;
  items?: string; // Comma separated or JSON string
  transactionId?: string; // External ID from POS
  phone?: string; // From CSV
  email?: string; // From CSV
  isMatched: boolean;
  importBatchId?: string;
}

export type ImportStatus = 'processing' | 'completed' | 'failed';

export interface SalesImportBatch {
  id: string;
  barId: string;
  filename: string;
  totalRows: number;
  matchedRows: number;
  unmatchedRows: number;
  totalRevenue: number;
  importDate: string;
  status: ImportStatus;
}

export type CampaignType = 'sms' | 'email' | 'both';
export type CampaignStatus = 'draft' | 'scheduled' | 'sending' | 'sent' | 'failed';

export interface Campaign {
  id: string;
  barId: string;
  name: string;
  type: CampaignType;
  subject?: string;
  message: string;
  status: CampaignStatus;
  sentAt?: string;
  scheduledAt?: string;
  recipientCount: number;
  successCount: number;
  failureCount: number;
  
  // ROI Tracking
  revenueBefore?: number;
  revenueAfter?: number;
}

export interface DashboardStats {
  totalCustomers: number;
  customerGrowth: number; // %
  newCustomers: number;
  newCustomersGrowth: number; // %
  totalRevenue: number;
  revenueGrowth: number; // %
  avgCustomerValue: number;
  avgValueGrowth: number; // %
}

export interface ChartDataPoint {
  name: string;
  value: number;
  value2?: number; // For comparison lines
}

// --- NEW TYPES FOR ADVANCED DASHBOARD ---

export interface SalesVelocity {
  wtd: number;
  wtdGrowth: number; // vs last week
  mtd: number;
  mtdGrowth: number; // vs last month
  ytd: number;
  ytdGrowth: number; // vs last year
  pacePercentage: number; // e.g. 103%
  paceStatus: 'on-track' | 'behind' | 'ahead';
}

export interface AiActionItem {
  id: string;
  type: 'high-impact' | 'quick-win' | 'revenue-opp' | 'time-sensitive';
  title: string;
  description: string;
  revenuePotential?: number;
  actionLabel: string;
}

export interface SegmentStat {
  id: string;
  label: string;
  count: number;
  wtdRevenue: number;
  trend?: string; // description
  status: 'healthy' | 'neutral' | 'risk';
}

export interface HeatmapPoint {
  day: string;
  hour: number; // 0-23
  intensity: number; // 0-100
}

export interface StaffStat {
  name: string;
  role: string;
  revenue: number;
  signups: number;
}

export interface InventoryItem {
  name: string;
  category: string;
  salesVolume: number;
  trend: 'up' | 'down';
  action: string;
}

// --- WEBSITE ANALYTICS TYPES ---
export interface WebsiteStats {
  visits: number;
  visitsGrowth: number;
  pageViews: number;
  bounceRate: number;
  avgTimeOnSite: string;
  topSources: { source: string; percentage: number }[];
  lastUpdated: string;
}

// --- SALES FORECAST TYPES ---
export interface SalesForecast {
  currentWeeklyPace: number;
  targetWeeklyPace: number;
  yesterdayTotal: number;
  yesterdayGrowth: number; // vs same day last week
  bestDayThisWeek: { day: string; amount: number };
  avgDailyRate: number;
  weekendForecast: number;
  aiInsights: string[];
}

export interface HourlyComparison {
  hour: string; // "5pm"
  today: number;
  average: number; // "Average Thursday"
}

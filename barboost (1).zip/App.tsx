
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { LandingPage } from './pages/LandingPage';
import { SignupPage } from './pages/SignupPage';
import { LoginPage } from './pages/LoginPage';
import { DashboardLayout } from './components/layouts/DashboardLayout';
import { OwnerDashboard } from './pages/owner/OwnerDashboard';
import { CustomersPage } from './pages/owner/CustomersPage';
import { CustomerDetailPage } from './pages/owner/CustomerDetailPage';
import { CampaignsPage } from './pages/owner/CampaignsPage';
import { BirthdaysPage } from './pages/owner/BirthdaysPage';
import { QrCodePage } from './pages/owner/QrCodePage';
import { SalesPage } from './pages/owner/SalesPage';
import { WebsitePage } from './pages/owner/WebsitePage';
import { AnalyticsPage } from './pages/owner/AnalyticsPage';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { User, UserRole } from './types';

// Simple Context for Auth
export const AuthContext = React.createContext<{
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => void;
}>({
  user: null,
  setUser: () => {},
  logout: () => {},
});

const ProtectedRoute = ({ allowedRoles }: { allowedRoles: UserRole[] }) => {
  const { user } = React.useContext(AuthContext);

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    if (user.role === UserRole.BAR_OWNER) return <Navigate to="/dashboard" replace />;
    if (user.role === UserRole.SUPER_ADMIN) return <Navigate to="/admin" replace />;
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, setUser, logout }}>
      <Router>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup/:barSlug" element={<SignupPage />} />

          {/* Bar Owner Routes */}
          <Route element={<ProtectedRoute allowedRoles={[UserRole.BAR_OWNER]} />}>
            <Route path="/dashboard" element={<DashboardLayout title="Dashboard" />}>
              <Route index element={<OwnerDashboard />} />
              <Route path="analytics" element={<AnalyticsPage />} />
              <Route path="sales" element={<SalesPage />} />
              <Route path="website" element={<WebsitePage />} />
              <Route path="customers" element={<CustomersPage />} />
              <Route path="customers/:id" element={<CustomerDetailPage />} />
              <Route path="birthdays" element={<BirthdaysPage />} />
              <Route path="campaigns/sms" element={<CampaignsPage defaultType="sms" />} />
              <Route path="campaigns/email" element={<CampaignsPage defaultType="email" />} />
              <Route path="qr" element={<QrCodePage />} />
            </Route>
          </Route>

          {/* Super Admin Routes */}
          <Route element={<ProtectedRoute allowedRoles={[UserRole.SUPER_ADMIN]} />}>
            <Route path="/admin" element={<DashboardLayout title="Admin Portal" />}>
              <Route index element={<AdminDashboard />} />
              <Route path="bars" element={<div className="p-8 text-slate-500">Bar Management Module (Placeholder)</div>} />
            </Route>
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  );
}

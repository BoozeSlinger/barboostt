
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart3, QrCode, Mail, ArrowRight, CheckCircle2, 
  Crown, Gem, TrendingUp, Users, Shield, Menu, X, Star, Wine
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Handle scroll effect for navbar
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-black text-zinc-300 font-sans selection:bg-luxury-gold selection:text-black overflow-x-hidden">
      
      {/* --- NAVIGATION --- */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-500 border-b ${scrolled ? 'bg-black/80 backdrop-blur-xl border-zinc-900 py-4' : 'bg-transparent border-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer group" onClick={() => window.scrollTo(0,0)}>
              <div className="relative p-1.5 border border-zinc-800 rounded-sm bg-black group-hover:border-luxury-gold/50 transition-colors duration-500">
                <Gem className="w-5 h-5 text-luxury-gold" />
              </div>
              <span className="font-serif text-xl text-white tracking-widest uppercase">BarBoost</span>
            </div>

            {/* Desktop Links */}
            <div className="hidden md:flex items-center gap-10">
              <a href="#features" className="text-xs font-medium uppercase tracking-widest text-zinc-500 hover:text-luxury-gold transition-colors">Philosophy</a>
              <a href="#solutions" className="text-xs font-medium uppercase tracking-widest text-zinc-500 hover:text-luxury-gold transition-colors">Capabilities</a>
              <a href="#pricing" className="text-xs font-medium uppercase tracking-widest text-zinc-500 hover:text-luxury-gold transition-colors">Membership</a>
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-6">
              <Link 
                to="/login?type=admin" 
                className="text-zinc-600 hover:text-luxury-gold transition-colors"
                title="Super Admin Access"
              >
                <Crown className="w-4 h-4" />
              </Link>
              <Link to="/login" className="text-xs font-bold uppercase tracking-widest text-white hover:text-luxury-gold transition-colors">
                Owner Login
              </Link>
              <Link 
                to="/signup/rusty-anchor" 
                className="bg-white text-black px-6 py-2.5 rounded-sm text-xs font-bold uppercase tracking-widest hover:bg-luxury-gold hover:text-black transition-all duration-300"
              >
                Request Access
              </Link>
            </div>

            {/* Mobile Menu Toggle */}
            <button className="md:hidden text-zinc-300" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 w-full bg-zinc-950 border-b border-zinc-900 p-6 flex flex-col gap-6 shadow-2xl">
            <a href="#features" className="text-zinc-300 text-sm uppercase tracking-widest" onClick={() => setMobileMenuOpen(false)}>Philosophy</a>
            <a href="#pricing" className="text-zinc-300 text-sm uppercase tracking-widest" onClick={() => setMobileMenuOpen(false)}>Membership</a>
            <Link to="/login" className="text-zinc-300 text-sm uppercase tracking-widest">Owner Login</Link>
            <Link to="/signup/rusty-anchor" className="bg-luxury-gold text-black text-center py-3 rounded-sm font-bold uppercase tracking-widest">Request Access</Link>
          </div>
        )}
      </nav>

      {/* --- HERO SECTION --- */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-black-gradient">
        {/* Subtle Luxury Gradients */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-luxury-gold/5 rounded-full blur-[150px] pointer-events-none mix-blend-screen"></div>
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-zinc-800/10 rounded-full blur-[120px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            
            {/* Left: Copy */}
            <div className="text-center lg:text-left">
              <div className="inline-flex items-center gap-3 px-3 py-1 border-l border-luxury-gold mb-10 pl-4">
                <span className="text-luxury-gold text-xs font-bold uppercase tracking-[0.2em]">The Gold Standard in Hospitality</span>
              </div>
              
              <h1 className="text-5xl sm:text-7xl font-serif font-medium text-white mb-8 leading-[1.1]">
                Turn Patrons Into <br/>
                <span className="text-gold-gradient italic">Loyal Regulars.</span>
              </h1>
              
              <p className="text-lg text-zinc-400 mb-12 leading-relaxed max-w-xl mx-auto lg:mx-0 font-light">
                An elite operating system for high-end venues. Capture guest data, automate VIP experiences, and forecast revenue with precision.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start mb-16">
                <Link to="/signup/rusty-anchor" className="bg-luxury-gold text-black px-10 py-4 rounded-sm font-bold text-sm uppercase tracking-widest hover:bg-luxury-gold-light transition-all shadow-[0_0_30px_-10px_rgba(212,175,55,0.3)] flex items-center justify-center gap-3">
                  Book Private Demo <ArrowRight className="w-4 h-4" />
                </Link>
                <a href="#how-it-works" className="group flex items-center gap-3 text-zinc-400 hover:text-white transition-colors px-6 py-4">
                  <span className="text-sm font-medium uppercase tracking-widest border-b border-zinc-800 group-hover:border-white transition-all pb-1">Explore Features</span>
                </a>
              </div>

              <div className="flex items-center justify-center lg:justify-start gap-12 border-t border-zinc-900 pt-8">
                <div>
                    <p className="text-3xl font-serif text-white">27%</p>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">Repeat Visits</p>
                </div>
                <div>
                    <p className="text-3xl font-serif text-white">$42k</p>
                    <p className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">Avg Revenue Lift</p>
                </div>
              </div>
            </div>

            {/* Right: Abstract UI Representation */}
            <div className="relative h-[600px] w-full flex items-center justify-center">
                {/* Decorative Rings */}
                <div className="absolute inset-0 border border-zinc-900 rounded-full scale-75 opacity-20"></div>
                <div className="absolute inset-0 border border-zinc-800 rounded-full scale-50 opacity-10"></div>
                
                {/* Main Card */}
                <div className="relative w-full max-w-md bg-zinc-950 border border-zinc-800 shadow-2xl p-1 z-10 animate-fade-in-up">
                    <div className="bg-black p-6 h-full relative overflow-hidden">
                        {/* Gold Shine Effect */}
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-luxury-gold to-transparent opacity-50"></div>
                        
                        {/* Header */}
                        <div className="flex justify-between items-center mb-8">
                            <div>
                                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Revenue Forecast</p>
                                <p className="text-xl text-white font-serif">Friday, Oct 24</p>
                            </div>
                            <div className="px-3 py-1 border border-zinc-800 rounded-full text-[10px] text-luxury-gold uppercase tracking-widest flex items-center gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-luxury-gold animate-pulse"></span> Live
                            </div>
                        </div>

                        {/* Chart Area */}
                        <div className="h-48 flex items-end justify-between gap-2 mb-8 relative">
                            {/* Grid Lines */}
                            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                                <div className="w-full h-px bg-zinc-900"></div>
                                <div className="w-full h-px bg-zinc-900"></div>
                                <div className="w-full h-px bg-zinc-900"></div>
                            </div>
                            {/* Bars */}
                            {[40, 65, 45, 80, 55, 90, 70].map((h, i) => (
                                <div key={i} className="w-full bg-zinc-900 relative group transition-all duration-500 hover:bg-zinc-800" style={{ height: `${h}%` }}>
                                    <div className="absolute bottom-0 w-full bg-gradient-to-t from-luxury-gold/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity h-full"></div>
                                    <div className="absolute top-0 w-full h-0.5 bg-luxury-gold opacity-0 group-hover:opacity-100"></div>
                                </div>
                            ))}
                        </div>

                        {/* Stats Row */}
                        <div className="grid grid-cols-2 gap-4 border-t border-zinc-900 pt-6">
                            <div>
                                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Projected</p>
                                <p className="text-lg text-white font-serif mt-1">$18,450</p>
                            </div>
                            <div className="text-right">
                                <p className="text-[10px] text-zinc-500 uppercase tracking-widest">Status</p>
                                <p className="text-lg text-luxury-gold font-serif mt-1 italic">On Pace</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Floating Card */}
                <div className="absolute bottom-20 -left-10 bg-zinc-900 border border-zinc-800 p-4 shadow-xl max-w-[240px] z-20">
                    <div className="flex items-center gap-3 mb-2">
                        <div className="p-1.5 bg-black border border-zinc-800">
                            <Crown className="w-4 h-4 text-luxury-gold" />
                        </div>
                        <p className="text-xs text-zinc-300 font-medium uppercase tracking-wide">VIP Alert</p>
                    </div>
                    <p className="text-xs text-zinc-500 leading-relaxed">
                        <span className="text-white">James St. Patrick</span> just checked in. Lifetime spend: <span className="text-luxury-gold">$12,400</span>.
                    </p>
                </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- SOCIAL PROOF --- */}
      <section className="border-y border-zinc-900 bg-zinc-950 py-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-[10px] text-zinc-600 font-bold uppercase tracking-[0.3em] mb-10">Trusted by World-Class Venues</p>
          <div className="flex flex-wrap justify-center gap-16 md:gap-24 opacity-30 grayscale hover:opacity-100 hover:grayscale-0 transition-all duration-700">
             <span className="text-2xl font-serif text-white">The Grand</span>
             <span className="text-2xl font-sans font-light tracking-[0.2em] text-white">NOIR</span>
             <span className="text-2xl font-serif italic text-white">Vesper</span>
             <span className="text-2xl font-mono text-white tracking-widest">APEX</span>
             <span className="text-2xl font-serif font-bold text-white">SOHO HOUSE</span>
          </div>
        </div>
      </section>

      {/* --- PROBLEM / SOLUTION (Minimalist) --- */}
      <section className="py-32 bg-black" id="solutions">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
           <div className="grid md:grid-cols-2 gap-20">
              <div>
                 <h2 className="text-4xl font-serif text-white mb-8">Refining the Art of <br/> Hospitality.</h2>
                 <p className="text-zinc-400 font-light leading-relaxed mb-8">
                    Modern venues rely on data, not intuition. The old ways of promoting—flyers, generic ads, and hope—are incompatible with today's discerning clientele.
                 </p>
                 <div className="h-px w-20 bg-luxury-gold mb-8"></div>
                 <p className="text-zinc-500 text-sm leading-relaxed">
                    BarBoost introduces a layer of digital intelligence to your operations, ensuring every night performs to its maximum potential.
                 </p>
              </div>
              <div className="space-y-8">
                 {[
                    { title: "Audience Ownership", desc: "Bypass algorithms. Reach your VIPs directly via SMS." },
                    { title: "Demand Generation", desc: "Fill tables on slow nights with a single targeted message." },
                    { title: "Revenue Intelligence", desc: "Predict sales volume with 92% accuracy using proprietary AI." }
                 ].map((item, i) => (
                    <div key={i} className="group cursor-default">
                        <div className="flex items-baseline gap-4 mb-2">
                            <span className="text-xs text-luxury-gold/50 font-mono">0{i+1}</span>
                            <h3 className="text-xl font-serif text-zinc-300 group-hover:text-white transition-colors">{item.title}</h3>
                        </div>
                        <p className="text-sm text-zinc-600 pl-8 group-hover:text-zinc-500 transition-colors">{item.desc}</p>
                    </div>
                 ))}
              </div>
           </div>
        </div>
      </section>

      {/* --- FEATURES GRID (Luxury Style) --- */}
      <section className="py-32 bg-zinc-950 relative" id="features">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-zinc-900/20 via-black to-black"></div>
        
        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10">
          <div className="text-center mb-24">
            <h2 className="text-3xl md:text-5xl font-serif text-white mb-6">Capabilities</h2>
            <div className="h-1 w-1 bg-luxury-gold mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-zinc-900 border border-zinc-900">
            {/* Feature 1 */}
            <div className="md:col-span-2 bg-black p-12 group hover:bg-zinc-950 transition-colors relative overflow-hidden">
               <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity">
                  <TrendingUp className="w-64 h-64 text-luxury-gold" />
               </div>
               <div className="relative z-10">
                  <div className="w-12 h-12 border border-zinc-800 flex items-center justify-center mb-8 group-hover:border-luxury-gold/50 transition-colors">
                     <BarChart3 className="w-5 h-5 text-luxury-gold" />
                  </div>
                  <h3 className="text-2xl font-serif text-white mb-4">Predictive Analytics</h3>
                  <p className="text-zinc-500 font-light max-w-md leading-relaxed">
                    Our algorithms analyze historical data, weather patterns, and local events to forecast revenue with unprecedented accuracy. Staff perfectly, every shift.
                  </p>
               </div>
            </div>

            {/* Feature 2 */}
            <div className="bg-black p-12 group hover:bg-zinc-950 transition-colors">
               <div className="w-12 h-12 border border-zinc-800 flex items-center justify-center mb-8 group-hover:border-luxury-gold/50 transition-colors">
                  <QrCode className="w-5 h-5 text-zinc-400 group-hover:text-luxury-gold transition-colors" />
               </div>
               <h3 className="text-xl font-serif text-white mb-4">Elegant Capture</h3>
               <p className="text-zinc-500 font-light text-sm leading-relaxed">
                 Beautiful, branded QR experiences that guests actually want to scan. No app downloads required.
               </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-black p-12 group hover:bg-zinc-950 transition-colors">
               <div className="w-12 h-12 border border-zinc-800 flex items-center justify-center mb-8 group-hover:border-luxury-gold/50 transition-colors">
                  <Mail className="w-5 h-5 text-zinc-400 group-hover:text-luxury-gold transition-colors" />
               </div>
               <h3 className="text-xl font-serif text-white mb-4">VIP Outreach</h3>
               <p className="text-zinc-500 font-light text-sm leading-relaxed">
                 Automated, personalized campaigns for birthdays and special events. Treat every guest like a regular.
               </p>
            </div>

             {/* Feature 4 */}
             <div className="md:col-span-2 bg-black p-12 group hover:bg-zinc-950 transition-colors">
               <div className="flex flex-col md:flex-row md:items-center gap-8">
                    <div className="w-12 h-12 border border-zinc-800 flex items-center justify-center shrink-0 group-hover:border-luxury-gold/50 transition-colors">
                        <Shield className="w-5 h-5 text-zinc-400 group-hover:text-luxury-gold transition-colors" />
                    </div>
                    <div>
                        <h3 className="text-xl font-serif text-white mb-2">Enterprise-Grade Security</h3>
                        <p className="text-zinc-500 font-light text-sm leading-relaxed max-w-lg">
                            Your guest data is your most valuable asset. We protect it with banking-level encryption and strict access controls.
                        </p>
                    </div>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- QUOTE --- */}
      <section className="py-32 bg-black relative">
        <div className="max-w-5xl mx-auto px-6 text-center">
           <Star className="w-6 h-6 text-luxury-gold mx-auto mb-8" />
           <h2 className="text-3xl md:text-5xl font-serif text-white mb-12 leading-tight italic">
              "BarBoost isn't just software. It is the sophisticated engine behind our most profitable nights."
           </h2>
           <div className="flex flex-col items-center gap-2">
              <p className="text-sm font-bold uppercase tracking-widest text-white">Michael Thorne</p>
              <p className="text-xs text-zinc-500 uppercase tracking-widest">Owner, The Rusty Anchor</p>
           </div>
        </div>
      </section>

      {/* --- PRICING (Membership) --- */}
      <section className="py-32 bg-zinc-950" id="pricing">
         <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h2 className="text-4xl font-serif text-white mb-6">Membership</h2>
                    <p className="text-zinc-400 font-light leading-relaxed mb-8">
                        Simple, transparent pricing designed for single locations and hospitality groups alike. 
                    </p>
                    <ul className="space-y-4 mb-10">
                        <li className="flex items-center gap-4">
                            <CheckCircle2 className="w-4 h-4 text-luxury-gold" />
                            <span className="text-sm text-zinc-300">Unlimited Guest Capture</span>
                        </li>
                        <li className="flex items-center gap-4">
                            <CheckCircle2 className="w-4 h-4 text-luxury-gold" />
                            <span className="text-sm text-zinc-300">AI Revenue Forecasting</span>
                        </li>
                        <li className="flex items-center gap-4">
                            <CheckCircle2 className="w-4 h-4 text-luxury-gold" />
                            <span className="text-sm text-zinc-300">Concierge Onboarding</span>
                        </li>
                    </ul>
                </div>
                
                <div className="bg-black border border-zinc-800 p-10 relative">
                    <div className="absolute top-0 right-0 p-4">
                        <span className="text-[10px] text-black bg-luxury-gold px-2 py-1 uppercase font-bold tracking-widest">Selected</span>
                    </div>
                    <h3 className="text-xl font-serif text-white mb-2">Growth Tier</h3>
                    <div className="flex items-baseline gap-1 mb-8">
                        <span className="text-4xl font-serif text-white">$199</span>
                        <span className="text-sm text-zinc-500">/ month</span>
                    </div>
                    <Link to="/signup/rusty-anchor" className="block w-full bg-zinc-900 border border-zinc-800 text-white text-center py-4 text-xs font-bold uppercase tracking-widest hover:bg-luxury-gold hover:text-black hover:border-luxury-gold transition-all duration-300">
                        Start Complimentary Trial
                    </Link>
                    <p className="text-center text-[10px] text-zinc-600 mt-4 uppercase tracking-widest">No commitment required</p>
                </div>
            </div>
         </div>
      </section>

      {/* --- FOOTER CTA --- */}
      <section className="py-32 border-t border-zinc-900 bg-black text-center">
         <div className="max-w-4xl mx-auto px-6">
            <h2 className="text-4xl md:text-6xl font-serif text-white mb-8">Elevate Your Venue.</h2>
            <p className="text-lg text-zinc-400 font-light mb-12">Join the exclusive network of venues using BarBoost.</p>
            <Link to="/signup/rusty-anchor" className="inline-block bg-luxury-gold text-black px-12 py-5 rounded-sm font-bold text-sm uppercase tracking-widest hover:bg-white transition-colors">
               Begin Your Journey
            </Link>
         </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="bg-black border-t border-zinc-900 pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
           <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-20">
              <div className="max-w-xs">
                 <div className="flex items-center gap-3 mb-6">
                    <div className="p-1 border border-zinc-800 rounded-sm">
                        <Gem className="w-4 h-4 text-luxury-gold" />
                    </div>
                    <span className="font-serif text-lg text-white tracking-widest uppercase">BarBoost</span>
                 </div>
                 <p className="text-zinc-600 text-xs leading-relaxed">
                    The premier operating system for the modern hospitality industry.
                 </p>
              </div>
              
              <div className="flex gap-20">
                 <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Platform</h4>
                    <ul className="space-y-4 text-xs text-zinc-500">
                        <li><a href="#" className="hover:text-luxury-gold transition-colors">Capabilities</a></li>
                        <li><a href="#" className="hover:text-luxury-gold transition-colors">Membership</a></li>
                        <li><a href="#" className="hover:text-luxury-gold transition-colors">Success Stories</a></li>
                    </ul>
                 </div>
                 <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-widest mb-6">Company</h4>
                    <ul className="space-y-4 text-xs text-zinc-500">
                        <li><a href="#" className="hover:text-luxury-gold transition-colors">About</a></li>
                        <li><a href="#" className="hover:text-luxury-gold transition-colors">Contact</a></li>
                        <li><Link to="/login?type=admin" className="hover:text-luxury-gold transition-colors">Admin</Link></li>
                    </ul>
                 </div>
              </div>
           </div>
           
           <div className="border-t border-zinc-900 pt-10 flex flex-col md:flex-row justify-between items-center text-[10px] text-zinc-700 uppercase tracking-widest">
              <p>© 2024 BarBoost Inc. All rights reserved.</p>
              <div className="flex gap-8 mt-4 md:mt-0">
                 <a href="#" className="hover:text-zinc-400">Privacy</a>
                 <a href="#" className="hover:text-zinc-400">Terms</a>
              </div>
           </div>
        </div>
      </footer>
    </div>
  );
};


import React, { useEffect, useState } from 'react';
import { mockService } from '../../services/mockService';
import { Card, CardContent } from '../../components/ui/Card';
import { BarChart3, Users, Store, Activity } from 'lucide-react';
import { Bar } from '../../types';

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<any>(null);
  const [bars, setBars] = useState<Bar[]>([]);

  useEffect(() => {
    mockService.getSystemStats().then(setStats);
    mockService.getAllBars().then(setBars);
  }, []);

  if (!stats) return <div className="text-slate-500">Loading...</div>;

  const StatCard = ({ title, value, icon: Icon, color, iconColor }: any) => (
    <Card className="bg-bg-card border-slate-800">
      <CardContent className="flex items-center p-6">
        <div className={`p-3 rounded-lg mr-4 bg-slate-900 border border-slate-700`}>
          <Icon className={`w-6 h-6 ${iconColor}`} />
        </div>
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <p className="text-2xl font-bold text-white">{value}</p>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-8">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Bars" value={stats.totalBars} icon={Store} iconColor="text-indigo-400" />
        <StatCard title="Total Customers" value={stats.totalCustomers} icon={Users} iconColor="text-blue-400" />
        <StatCard title="Campaigns Sent" value={stats.totalCampaigns} icon={BarChart3} iconColor="text-green-400" />
        <StatCard title="Active Bars" value={stats.activeBars} icon={Activity} iconColor="text-orange-400" />
      </div>

      {/* Bar Management List */}
      <Card className="bg-bg-card border-slate-800">
        <CardContent className="p-0">
          <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <h3 className="font-bold text-lg text-white">Registered Bars</h3>
          </div>
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/50 text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-6 py-4">Business Name</th>
                <th className="px-6 py-4">Owner</th>
                <th className="px-6 py-4">Email</th>
                <th className="px-6 py-4">Customers</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {bars.map((bar) => (
                <tr key={bar.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="px-6 py-4 font-medium text-white">{bar.businessName}</td>
                  <td className="px-6 py-4 text-slate-400">{bar.ownerName}</td>
                  <td className="px-6 py-4 text-slate-400">{bar.email}</td>
                  <td className="px-6 py-4 text-slate-400">{bar.customerCount}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${bar.isActive ? 'bg-green-900/30 text-green-400 border-green-900' : 'bg-red-900/30 text-red-400 border-red-900'}`}>
                      {bar.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-neon-blue hover:text-blue-400 font-medium transition-colors">Manage</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

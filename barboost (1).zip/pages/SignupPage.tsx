
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { mockService } from '../services/mockService';
import { Bar } from '../types';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Beer, Check, Loader2 } from 'lucide-react';

export const SignupPage: React.FC = () => {
  const { barSlug } = useParams<{ barSlug: string }>();
  const [bar, setBar] = useState<Bar | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    birthday: '',
    is21: false,
    optInSms: true,
    optInEmail: true,
  });

  useEffect(() => {
    const fetchBar = async () => {
      if (barSlug) {
        const foundBar = await mockService.getBarBySlug(barSlug);
        setBar(foundBar || null);
      }
      setLoading(false);
    };
    fetchBar();
  }, [barSlug]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bar) return;
    
    // Simple validation
    const birthDate = new Date(formData.birthday);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age < 21) {
      alert("You must be 21+ to join.");
      return;
    }

    setSubmitting(true);
    await mockService.createCustomer({
      barId: bar.id,
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
      birthday: formData.birthday,
      is21Plus: true,
      optInSms: formData.optInSms,
      optInEmail: formData.optInEmail,
    });
    setSubmitting(false);
    setSuccess(true);
  };

  if (loading) return (
    <div className="min-h-screen bg-bg-main flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-neon-blue" />
    </div>
  );

  if (!bar) return (
    <div className="min-h-screen bg-bg-main flex items-center justify-center text-slate-500">
      Bar not found. Please scan the QR code again.
    </div>
  );

  if (success) {
    return (
      <div className="min-h-screen bg-bg-main flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center p-8 bg-bg-card border-slate-800">
          <div className="mx-auto w-16 h-16 bg-green-900/30 border border-green-900 rounded-full flex items-center justify-center mb-4">
            <Check className="w-8 h-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">You're In!</h2>
          <p className="text-slate-400">Thanks for joining the {bar.businessName} VIP club. Watch your phone for exclusive deals!</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-main flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-neon-blue/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="mb-6 text-center relative z-10">
        <div className="inline-block p-4 bg-slate-900 border border-slate-800 rounded-full mb-4 shadow-xl shadow-black/50">
          <Beer className="w-8 h-8 text-neon-yellow" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-1">{bar.businessName}</h1>
        <p className="text-slate-400">Join our VIP Guest List</p>
      </div>

      <Card className="w-full max-w-md shadow-2xl bg-bg-card border-slate-800 relative z-10">
        <CardHeader className="bg-slate-900/50 border-b border-slate-800">
          <p className="text-sm text-center text-slate-400">Unlock exclusive offers, event invites, and free birthday drinks!</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">First Name</label>
                <Input
                  value={formData.firstName}
                  onChange={e => setFormData({...formData, firstName: e.target.value})}
                  required
                  className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Last Name</label>
                <Input
                  value={formData.lastName}
                  onChange={e => setFormData({...formData, lastName: e.target.value})}
                  required
                  className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Phone Number</label>
              <Input
                type="tel"
                placeholder="(555) 555-5555"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
                required
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Email (Optional)</label>
              <Input
                type="email"
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Birthday</label>
              <Input
                type="date"
                value={formData.birthday}
                onChange={e => setFormData({...formData, birthday: e.target.value})}
                required
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue [color-scheme:dark]"
              />
            </div>

            <div className="space-y-3 pt-2">
              <label className="flex items-start gap-3 p-3 border border-slate-800 rounded-lg bg-slate-900/50 hover:bg-slate-800 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  className="mt-1 accent-neon-blue bg-slate-900 border-slate-700"
                  checked={formData.is21}
                  onChange={e => setFormData({...formData, is21: e.target.checked})}
                  required
                />
                <span className="text-sm text-slate-300">I confirm I am 21 years of age or older.</span>
              </label>

              <label className="flex items-center gap-3 px-1 cursor-pointer">
                <input
                  type="checkbox"
                  className="accent-neon-blue bg-slate-900 border-slate-700"
                  checked={formData.optInSms}
                  onChange={e => setFormData({...formData, optInSms: e.target.checked})}
                />
                <span className="text-sm text-slate-400">Send me offers via SMS</span>
              </label>

              <label className="flex items-center gap-3 px-1 cursor-pointer">
                <input
                  type="checkbox"
                  className="accent-neon-blue bg-slate-900 border-slate-700"
                  checked={formData.optInEmail}
                  onChange={e => setFormData({...formData, optInEmail: e.target.checked})}
                />
                <span className="text-sm text-slate-400">Send me offers via Email</span>
              </label>
            </div>

            <Button type="submit" className="w-full mt-4 bg-neon-blue hover:bg-blue-600 text-white font-bold" size="lg" isLoading={submitting}>
              Join the Club
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <p className="mt-8 text-xs text-slate-500">Powered by BarBoost</p>
    </div>
  );
};

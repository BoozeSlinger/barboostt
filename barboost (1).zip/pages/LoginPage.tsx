
import React, { useState, useContext, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AuthContext } from '../App';
import { mockService } from '../services/mockService';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { UserRole } from '../types';
import { Zap } from 'lucide-react';

export const LoginPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [email, setEmail] = useState('sam@rustyanchor.com'); // Default for demo
  const [password, setPassword] = useState('password');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const { setUser } = useContext(AuthContext);
  const navigate = useNavigate();

  // Check for admin intent from URL
  useEffect(() => {
    if (searchParams.get('type') === 'admin') {
      setEmail('admin@barboost.com');
    }
  }, [searchParams]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const user = await mockService.login(email);
      if (user) {
        setUser(user);
        if (user.role === UserRole.SUPER_ADMIN) {
          navigate('/admin');
        } else {
          navigate('/dashboard');
        }
      } else {
        setError('Invalid credentials. Try sam@rustyanchor.com or admin@barboost.com');
      }
    } catch (err) {
      setError('An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg-main flex flex-col items-center justify-center p-4">
      <div className="mb-8 flex items-center gap-2">
         <div className="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
            <Zap className="w-6 h-6 text-neon-cyan" />
         </div>
         <span className="font-bold text-2xl text-white">BarBoost</span>
      </div>

      <Card className="w-full max-w-md bg-bg-card border-slate-800">
        <CardHeader className="border-slate-800">
          <CardTitle className="text-white">Welcome Back</CardTitle>
          <p className="text-slate-400 text-sm mt-1">
            Sign in to {email === 'admin@barboost.com' ? 'System Admin' : 'your dashboard'}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Email Address</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Password</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-slate-950 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
              />
            </div>
            
            {error && (
              <div className="bg-red-900/30 border border-red-900 text-red-400 text-sm p-3 rounded-lg">
                {error}
              </div>
            )}

            <Button type="submit" className="w-full bg-neon-blue hover:bg-blue-600 text-white" size="lg" isLoading={loading}>
              Sign In
            </Button>
            
            <div className="mt-4 text-center text-xs text-slate-500">
              <p>Demo Accounts:</p>
              <p className="mt-1">Owner: sam@rustyanchor.com</p>
              <p>Admin: admin@barboost.com</p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

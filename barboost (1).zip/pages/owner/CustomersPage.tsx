
import React, { useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { Customer } from '../../types';
import { Card, CardContent } from '../../components/ui/Card';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { Download, Search, Star } from 'lucide-react';

export const CustomersPage: React.FC = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (user?.barId) {
      mockService.getCustomers(user.barId).then(setCustomers);
    }
  }, [user]);

  const filteredCustomers = customers.filter(c => 
    c.lastName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.phone.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="relative w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <Input 
            placeholder="Search by name or phone..." 
            className="pl-9 bg-slate-900 border-slate-800 text-slate-200 placeholder-slate-500 focus:border-neon-cyan focus:ring-neon-cyan/20"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" size="sm" className="bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800 hover:text-white">
          <Download className="w-4 h-4 mr-2" />
          Export CSV
        </Button>
      </div>

      <Card className="bg-bg-card border-slate-800">
        <CardContent className="p-0">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/50 text-slate-400 font-medium border-b border-slate-800">
              <tr>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Phone</th>
                <th className="px-6 py-4">Total Spent</th>
                <th className="px-6 py-4">Visits</th>
                <th className="px-6 py-4">Tier</th>
                <th className="px-6 py-4">Joined</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredCustomers.map((customer) => (
                <tr 
                  key={customer.id} 
                  className="hover:bg-slate-800/50 transition-colors cursor-pointer"
                  onClick={() => navigate(`/dashboard/customers/${customer.id}`)}
                >
                  <td className="px-6 py-4 font-medium text-slate-200">
                    {customer.firstName} {customer.lastName}
                  </td>
                  <td className="px-6 py-4 text-slate-400">{customer.phone}</td>
                  <td className="px-6 py-4 text-neon-green font-medium">
                    ${customer.totalSpent.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 text-slate-400">{customer.visitCount}</td>
                  <td className="px-6 py-4">
                     {customer.tier === 'VIP' ? (
                       <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-bold bg-purple-900/30 text-purple-400 border border-purple-900/50">
                         <Star className="w-3 h-3 fill-current" /> VIP
                       </span>
                     ) : (
                       <span className="text-slate-500 text-xs">{customer.tier}</span>
                     )}
                  </td>
                  <td className="px-6 py-4 text-slate-500">{new Date(customer.signupDate).toLocaleDateString()}</td>
                </tr>
              ))}
              {filteredCustomers.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-slate-500">
                    No customers found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
};

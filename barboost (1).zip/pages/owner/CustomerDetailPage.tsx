
import React, { useContext, useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { Customer, SalesTransaction } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { ArrowLeft, Star, Calendar, DollarSign, Mail, Phone, ShoppingBag, Crown } from 'lucide-react';

export const CustomerDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useContext(AuthContext);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [sales, setSales] = useState<SalesTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (user?.barId && id) {
        const data = await mockService.getCustomerDetails(user.barId, id);
        if (data) {
          setCustomer(data.customer);
          setSales(data.sales);
        }
        setLoading(false);
      }
    };
    fetchData();
  }, [user, id]);

  if (loading) return <div className="text-zinc-500">Loading profile...</div>;
  if (!customer) return <div className="text-zinc-500">Customer not found</div>;

  return (
    <div className="space-y-8">
      <Link to="/dashboard/customers" className="inline-flex items-center text-zinc-500 hover:text-luxury-gold text-xs font-bold uppercase tracking-widest transition-colors">
        <ArrowLeft className="w-3 h-3 mr-2" /> Back to List
      </Link>

      {/* Header Profile */}
      <Card className="bg-zinc-950 border-zinc-900 shadow-none">
        <CardContent className="p-8">
          <div className="flex flex-col md:flex-row justify-between md:items-start gap-8">
            <div>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-black border border-zinc-800 flex items-center justify-center">
                    <span className="text-2xl font-serif text-white">{customer.firstName[0]}{customer.lastName[0]}</span>
                </div>
                <div>
                    <h1 className="text-3xl font-serif text-white mb-1">{customer.firstName} {customer.lastName}</h1>
                    <span className={`px-2 py-0.5 text-[10px] uppercase tracking-widest font-bold border 
                    ${customer.customerTier === 'VIP' ? 'bg-black text-luxury-gold border-luxury-gold' : 
                        customer.customerTier === 'Regular' ? 'bg-black text-zinc-300 border-zinc-700' : 
                        'bg-zinc-900 text-zinc-500 border-zinc-800'}`}>
                    {customer.customerTier}
                    </span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-6 text-zinc-400 text-xs font-light">
                <div className="flex items-center gap-2 hover:text-white transition-colors">
                  <Phone className="w-3 h-3 text-zinc-600" /> {customer.phone}
                </div>
                <div className="flex items-center gap-2 hover:text-white transition-colors">
                  <Mail className="w-3 h-3 text-zinc-600" /> {customer.email || 'No email'}
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-3 h-3 text-zinc-600" /> Joined {new Date(customer.signupDate).toLocaleDateString()}
                </div>
              </div>
            </div>
            
            <div className="flex gap-4">
               <div className="text-center px-8 py-4 bg-black border border-zinc-900 min-w-[140px]">
                  <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-1">Lifetime Spend</p>
                  <p className="text-2xl font-serif text-white">${customer.totalSpent.toFixed(2)}</p>
               </div>
               <div className="text-center px-8 py-4 bg-black border border-zinc-900 min-w-[140px]">
                  <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-1">Visits</p>
                  <p className="text-2xl font-serif text-white">{customer.totalVisits}</p>
               </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Purchase History Timeline */}
        <div className="md:col-span-2 space-y-6">
          <h2 className="text-sm font-bold text-white uppercase tracking-widest">History</h2>
          {sales.length === 0 ? (
             <Card className="bg-zinc-950 border-zinc-900 border-dashed">
               <CardContent className="p-12 text-center text-zinc-500 font-light text-sm">
                 No linked transactions found. Upload POS data to see history.
               </CardContent>
             </Card>
          ) : (
            sales.map(sale => (
              <Card key={sale.id} className="bg-zinc-950 border-zinc-900 hover:border-zinc-800 transition-colors group">
                <CardContent className="p-5 flex justify-between items-center">
                  <div className="flex items-start gap-5">
                    <div className="bg-black p-3 border border-zinc-800 group-hover:border-luxury-gold/30 transition-colors">
                      <ShoppingBag className="w-4 h-4 text-zinc-400 group-hover:text-luxury-gold" />
                    </div>
                    <div>
                      <p className="font-serif text-zinc-200 text-lg">{new Date(sale.transactionDate).toLocaleDateString()}</p>
                      <p className="text-xs text-zinc-500 mt-1 font-mono">{sale.items || 'General Sale'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-white font-mono">${sale.amount.toFixed(2)}</p>
                    <p className="text-[10px] text-zinc-600 uppercase tracking-widest">POS Import</p>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <Card className="bg-zinc-950 border-zinc-900">
            <CardHeader className="border-zinc-900">
               <CardTitle className="text-white text-sm font-bold uppercase tracking-widest">Profile Insights</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
               <div>
                 <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">Last Visit</p>
                 <p className="text-zinc-200 font-serif text-lg">{customer.lastVisitDate ? new Date(customer.lastVisitDate).toLocaleDateString() : 'Never'}</p>
               </div>
               <div className="h-px bg-zinc-900"></div>
               <div>
                 <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-2">Communication Preferences</p>
                 <div className="flex gap-2">
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wide border ${customer.optInSms ? 'bg-black text-white border-zinc-700' : 'bg-black text-zinc-600 border-zinc-800'}`}>
                      SMS: {customer.optInSms ? 'ON' : 'OFF'}
                    </span>
                    <span className={`px-2 py-1 text-[10px] font-bold uppercase tracking-wide border ${customer.optInEmail ? 'bg-black text-white border-zinc-700' : 'bg-black text-zinc-600 border-zinc-800'}`}>
                      Email: {customer.optInEmail ? 'ON' : 'OFF'}
                    </span>
                 </div>
               </div>
               <div className="h-px bg-zinc-900"></div>
               <div>
                  <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider mb-1">Birthday</p>
                  <p className="text-zinc-200 font-serif text-lg">{new Date(customer.birthday).toLocaleDateString()}</p>
               </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

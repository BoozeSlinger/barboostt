
import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { Customer } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Cake, Save, Send } from 'lucide-react';

export const BirthdaysPage: React.FC = () => {
  const { user } = useContext(AuthContext);
  const [upcomingBirthdays, setUpcomingBirthdays] = useState<Customer[]>([]);
  const [template, setTemplate] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (user?.barId) {
      loadData(user.barId);
    }
  }, [user]);

  const loadData = async (barId: string) => {
    setLoading(true);
    const [customers, msg] = await Promise.all([
      mockService.getUpcomingBirthdays(barId),
      mockService.getBirthdayTemplate(barId)
    ]);
    setUpcomingBirthdays(customers);
    setTemplate(msg);
    setLoading(false);
  };

  const handleSaveTemplate = async () => {
    if (!user?.barId) return;
    setSaving(true);
    await mockService.updateBirthdayTemplate(user.barId, template);
    setSaving(false);
    alert('Birthday message template saved!');
  };

  const handleSendAll = async () => {
    if (!user?.barId || upcomingBirthdays.length === 0) return;
    if (!confirm(`Send birthday SMS to ${upcomingBirthdays.length} customers?`)) return;

    setSending(true);
    const customerIds = upcomingBirthdays.map(c => c.id);
    await mockService.sendBirthdayCampaign(user.barId, customerIds, template);
    setSending(false);
    alert('Birthday messages sent successfully!');
  };

  const getAgeTurning = (birthday: string) => {
    const today = new Date();
    const birthDate = new Date(birthday);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--; // Age right now
    }
    return age + 1; // Turning age
  };

  const formatDate = (dateString: string) => {
    const d = new Date(dateString);
    // Return Month Day format (e.g. "October 24")
    return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric' });
  };

  if (loading) return <div className="text-slate-500">Loading birthday data...</div>;

  return (
    <div className="space-y-6">
      {/* Configuration Section */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="md:col-span-2 bg-bg-card border-slate-800">
          <CardHeader className="border-slate-800">
            <CardTitle className="text-white">Upcoming Birthdays (Next 7 Days)</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {upcomingBirthdays.length > 0 ? (
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-900/50 text-slate-400 font-medium border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-4">Name</th>
                    <th className="px-6 py-4">Birthday</th>
                    <th className="px-6 py-4">Turning</th>
                    <th className="px-6 py-4">Phone</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {upcomingBirthdays.map((c) => (
                    <tr key={c.id}>
                      <td className="px-6 py-4 font-medium text-slate-200">{c.firstName} {c.lastName}</td>
                      <td className="px-6 py-4 text-slate-400">{formatDate(c.birthday)}</td>
                      <td className="px-6 py-4 text-slate-400">{getAgeTurning(c.birthday)}</td>
                      <td className="px-6 py-4 text-slate-400">{c.phone}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="p-8 text-center text-slate-500">
                No birthdays found in the next 7 days.
              </div>
            )}
            
            {upcomingBirthdays.length > 0 && (
              <div className="p-4 border-t border-slate-800 bg-slate-900/30 flex justify-end">
                <Button onClick={handleSendAll} isLoading={sending} className="bg-neon-blue hover:bg-neon-blue/80 text-white">
                  <Send className="w-4 h-4 mr-2" />
                  Send SMS to All ({upcomingBirthdays.length})
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Message Editor Section */}
        <Card className="h-fit bg-bg-card border-slate-800">
          <CardHeader className="bg-slate-900/50 border-b border-slate-800">
            <div className="flex items-center gap-2 text-neon-cyan">
              <Cake className="w-5 h-5" />
              <h3 className="font-bold">Automated Message</h3>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 pt-6">
            <p className="text-sm text-slate-400">
              Customize the message sent to customers for their birthday. 
              Reply STOP logic is appended automatically.
            </p>
            <textarea
              className="w-full h-40 px-3 py-2 bg-slate-950 border border-slate-800 rounded-md focus:ring-1 focus:ring-neon-cyan focus:border-neon-cyan text-sm text-slate-200 placeholder-slate-600"
              value={template}
              onChange={(e) => setTemplate(e.target.value)}
              placeholder="Enter your birthday offer message..."
            />
            <div className="flex justify-end">
              <Button variant="secondary" onClick={handleSaveTemplate} isLoading={saving} size="sm" className="bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700">
                <Save className="w-4 h-4 mr-2" />
                Save Template
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

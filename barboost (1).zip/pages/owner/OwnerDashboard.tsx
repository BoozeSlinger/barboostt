
import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { ChartDataPoint, SalesVelocity, AiActionItem, SegmentStat, HeatmapPoint, StaffStat, InventoryItem } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Users, TrendingUp, DollarSign, ArrowUpRight, ArrowDownRight, Flame, Zap, Clock, CloudRain, Trophy, Send, Gem, Crown } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

// --- WIDGETS ---

const VelocityCard = ({ title, value, growth, subtext, highlight = false }: any) => (
  <div className={`relative bg-zinc-950 border ${highlight ? 'border-luxury-gold/50 shadow-[0_0_15px_-5px_rgba(212,175,55,0.3)]' : 'border-zinc-900'} p-6 group transition-all hover:bg-zinc-900`}>
     {highlight && <div className="absolute top-0 right-0 px-2 py-1 bg-luxury-gold text-black text-[10px] font-bold uppercase tracking-widest">Pace</div>}
     <div className="flex justify-between items-start mb-4">
        <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em]">{title}</p>
        {growth !== undefined && (
          <div className={`flex items-center text-xs font-medium ${growth >= 0 ? 'text-luxury-gold' : 'text-red-400'}`}>
             {growth >= 0 ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
             {Math.abs(growth)}%
          </div>
        )}
     </div>
     <h3 className={`text-3xl font-serif text-white mb-1`}>{value}</h3>
     <p className="text-[10px] text-zinc-600">{subtext}</p>
     {highlight && <div className="absolute bottom-0 left-0 h-0.5 w-full bg-luxury-gold"></div>}
  </div>
);

const ActionRow: React.FC<{ item: AiActionItem }> = ({ item }) => {
  const icons: Record<string, React.ReactNode> = {
    'high-impact': <Flame className="w-4 h-4 text-luxury-gold" />,
    'quick-win': <Zap className="w-4 h-4 text-zinc-400" />,
    'revenue-opp': <DollarSign className="w-4 h-4 text-green-400" />,
    'time-sensitive': <Clock className="w-4 h-4 text-red-400" />,
  };

  return (
    <div className="flex items-center justify-between p-4 bg-zinc-900/30 border border-zinc-900 hover:border-zinc-800 transition-colors">
      <div className="flex items-start gap-4">
        <div className="p-2 bg-black border border-zinc-800 rounded-sm">{icons[item.type]}</div>
        <div>
          <h4 className="font-serif text-zinc-200 text-sm flex items-center gap-2">
            {item.title} 
            {item.revenuePotential && <span className="text-[10px] px-1.5 py-0.5 bg-green-900/20 text-green-400 border border-green-900/50 uppercase tracking-wide">Est. ${item.revenuePotential}</span>}
          </h4>
          <p className="text-zinc-500 text-xs mt-1 font-light">{item.description}</p>
        </div>
      </div>
      <Button size="sm" variant="outline" className="text-xs uppercase tracking-widest border-zinc-800 text-zinc-400 hover:text-white hover:border-white bg-transparent">
        {item.actionLabel}
      </Button>
    </div>
  );
};

const SegmentCard: React.FC<{ stat: SegmentStat }> = ({ stat }) => (
  <div className="bg-zinc-950 border border-zinc-900 p-5 hover:border-zinc-700 transition-colors group">
    <div className="flex justify-between items-start mb-4">
      <h4 className="text-zinc-400 font-bold text-xs uppercase tracking-widest group-hover:text-luxury-gold transition-colors">{stat.label}</h4>
      <span className={`w-1.5 h-1.5 rounded-full ${stat.status === 'healthy' ? 'bg-green-500' : stat.status === 'risk' ? 'bg-red-500' : 'bg-zinc-600'}`}></span>
    </div>
    <div className="flex items-baseline gap-2 mb-2">
      <span className="text-2xl font-serif text-white">{stat.count}</span>
      <span className="text-[10px] text-zinc-600 uppercase">patrons</span>
    </div>
    <div className="h-px w-full bg-zinc-900 my-3"></div>
    <p className="text-xs text-zinc-500 mb-1 font-mono">${stat.wtdRevenue.toLocaleString()} <span className="text-[10px] text-zinc-700">WTD</span></p>
    {stat.trend && <p className={`text-[10px] italic ${stat.status === 'risk' ? 'text-red-400' : 'text-green-400'}`}>{stat.trend}</p>}
  </div>
);

export const OwnerDashboard: React.FC = () => {
  const { user } = useContext(AuthContext);
  const [velocity, setVelocity] = useState<SalesVelocity | null>(null);
  const [actions, setActions] = useState<AiActionItem[]>([]);
  const [segments, setSegments] = useState<SegmentStat[]>([]);
  const [revenueData, setRevenueData] = useState<ChartDataPoint[]>([]);
  const [heatmap, setHeatmap] = useState<HeatmapPoint[]>([]);
  const [staff, setStaff] = useState<StaffStat[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);

  useEffect(() => {
    const loadData = async () => {
      if (user?.barId) {
        const [vel, act, seg, rev, heat, stf, inv] = await Promise.all([
          mockService.getSalesVelocity(user.barId),
          mockService.getAiActionItems(user.barId),
          mockService.getSmartSegments(user.barId),
          mockService.getRevenueChartData(user.barId),
          mockService.getHeatmapData(user.barId),
          mockService.getStaffLeaderboard(user.barId),
          mockService.getInventoryInsights(user.barId)
        ]);
        setVelocity(vel);
        setActions(act);
        setSegments(seg);
        setRevenueData(rev);
        setHeatmap(heat);
        setStaff(stf);
        setInventory(inv);
      }
    };
    loadData();
  }, [user]);

  if (!velocity) return <div className="p-8 text-zinc-500 font-light">Loading intelligence engine...</div>;

  return (
    <div className="space-y-10 pb-10">
      {/* Campaign Ticker - Top Bar */}
      <div className="bg-zinc-950 border border-zinc-900 p-3 flex items-center gap-6 overflow-hidden text-xs">
         <span className="flex items-center gap-2 text-luxury-gold font-bold uppercase tracking-widest text-[10px] shrink-0 border-r border-zinc-800 pr-4">
            <span className="w-1.5 h-1.5 rounded-full bg-luxury-gold animate-pulse"></span> Live Feed
         </span>
         <div className="flex gap-12 animate-marquee whitespace-nowrap text-zinc-500 font-mono">
            <span>VIP Birthday: <span className="text-zinc-300">12 visits ($340 rev)</span></span>
            <span>Flash Sale: <span className="text-zinc-300">45 clicks, 8 redeems</span></span>
            <span>Win-Back: <span className="text-zinc-300">3 returns confirmed</span></span>
         </div>
      </div>

      {/* 1. SALES VELOCITY INDICATORS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-px bg-zinc-900 border border-zinc-900">
         <VelocityCard 
            title="WTD Sales" 
            value={`$${velocity.wtd.toLocaleString()}`} 
            growth={velocity.wtdGrowth} 
            subtext="vs last week" 
         />
         <VelocityCard 
            title="MTD Sales" 
            value={`$${velocity.mtd.toLocaleString()}`} 
            growth={velocity.mtdGrowth} 
            subtext="vs last month" 
         />
         <VelocityCard 
            title="YTD Sales" 
            value={`$${(velocity.ytd / 1000).toFixed(1)}k`} 
            growth={velocity.ytdGrowth} 
            subtext="vs last year" 
         />
         <VelocityCard 
            title="Current Pace" 
            value={`${velocity.pacePercentage}%`} 
            subtext={velocity.paceStatus === 'ahead' ? "Ahead of schedule" : "Behind schedule"} 
            highlight={true}
         />
      </div>

      {/* 2. AI ACTION ITEMS */}
      <Card className="border-zinc-900 bg-zinc-950 shadow-none">
        <CardHeader className="border-zinc-900 pb-4">
           <CardTitle className="text-white font-serif flex items-center gap-3">
              <Gem className="w-4 h-4 text-luxury-gold" /> 
              Intelligence Console
              <span className="text-[10px] font-sans font-normal text-zinc-500 border border-zinc-800 px-2 py-0.5 ml-auto uppercase tracking-widest">Priority Sorted</span>
           </CardTitle>
        </CardHeader>
        <CardContent>
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {actions.map(action => <ActionRow key={action.id} item={action} />)}
           </div>
        </CardContent>
      </Card>

      {/* 3. SMART SEGMENTS */}
      <div>
        <h3 className="text-zinc-500 font-bold text-xs uppercase tracking-[0.2em] mb-4 flex items-center gap-2">Audience Health</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
           {segments.map(seg => <SegmentCard key={seg.id} stat={seg} />)}
        </div>
      </div>

      {/* 4. CHARTS & HEATMAP */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         {/* Left: Revenue Trend + Compare */}
         <Card className="lg:col-span-2 border-zinc-900 bg-zinc-950 shadow-none">
           <CardHeader className="border-zinc-900 flex flex-row items-center justify-between">
              <CardTitle className="text-white font-serif">Revenue Trend</CardTitle>
              <div className="flex items-center gap-2 px-3 py-1 bg-black border border-zinc-800 text-[10px] uppercase tracking-wider text-zinc-500">
                 <CloudRain className="w-3 h-3 text-zinc-400" />
                 <span>Rain Expected Fri</span>
              </div>
           </CardHeader>
           <CardContent className="h-80">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={revenueData}>
                 <defs>
                   <linearGradient id="colorCurrent" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.2}/>
                     <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 10, textTransform: 'uppercase'}} dy={10} />
                 <YAxis axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 10}} prefix="$" />
                 <Tooltip 
                   contentStyle={{backgroundColor: '#000', borderColor: '#27272a', color: '#fff', borderRadius: '0px', fontFamily: 'serif'}}
                 />
                 <Area type="monotone" dataKey="value" name="This Week" stroke="#D4AF37" strokeWidth={2} fillOpacity={1} fill="url(#colorCurrent)" />
                 <Area type="monotone" dataKey="value2" name="Last Week" stroke="#52525b" strokeWidth={1} strokeDasharray="4 4" fill="none" />
                 <Legend wrapperStyle={{ fontSize: '10px', textTransform: 'uppercase', color: '#71717a' }}/>
               </AreaChart>
             </ResponsiveContainer>
           </CardContent>
         </Card>

         {/* Right: Busiest Times Heatmap (Custom Visual) */}
         <Card className="border-zinc-900 bg-zinc-950 shadow-none">
            <CardHeader className="border-zinc-900">
               <CardTitle className="text-white font-serif">Peak Intensity</CardTitle>
            </CardHeader>
            <CardContent>
               <div className="grid grid-cols-8 gap-1 text-[10px] text-zinc-600 font-mono">
                  {/* Header Row */}
                  <div className="col-span-1"></div>
                  {['M','T','W','T','F','S','S'].map((d,i) => <div key={i} className="text-center">{d}</div>)}

                  {/* Hour Rows (Simplified: 4pm - 11pm) */}
                  {[16,17,18,19,20,21,22,23].map(hour => (
                     <React.Fragment key={hour}>
                        <div className="text-right pr-2 pt-1">{hour > 12 ? hour-12 : hour}{hour >= 12 ? 'p' : 'a'}</div>
                        {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(day => {
                           // Find intensity from mock data
                           const point = heatmap.find(p => p.day === day && p.hour === hour);
                           const intensity = point?.intensity || 0;
                           let bgClass = 'bg-zinc-900';
                           if(intensity > 80) bgClass = 'bg-luxury-gold';
                           else if(intensity > 50) bgClass = 'bg-luxury-gold/50';
                           else if(intensity > 20) bgClass = 'bg-zinc-800';

                           return (
                              <div key={`${day}-${hour}`} className={`h-6 w-full ${bgClass} transition-all hover:opacity-80 cursor-pointer`} title={`${day} ${hour}:00 - Capacity: ${intensity}%`}></div>
                           )
                        })}
                     </React.Fragment>
                  ))}
               </div>
               <div className="flex justify-between mt-6 text-[10px] text-zinc-500 px-2 uppercase tracking-wider">
                  <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-zinc-900"></div> Low</div>
                  <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-zinc-800"></div> Mod</div>
                  <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-luxury-gold/50"></div> Busy</div>
                  <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 bg-luxury-gold"></div> Peak</div>
               </div>
            </CardContent>
         </Card>
      </div>

      {/* 5. OPERATIONAL INSIGHTS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         {/* Staff Leaderboard */}
         <Card className="border-zinc-900 bg-zinc-950 shadow-none">
            <CardHeader className="border-zinc-900 pb-2 flex flex-row justify-between items-center">
               <CardTitle className="text-white font-serif">Staff Performance</CardTitle>
               <Trophy className="w-4 h-4 text-luxury-gold" />
            </CardHeader>
            <CardContent className="p-0">
               <table className="w-full text-left text-sm">
                  <thead className="bg-zinc-900/30 text-zinc-500 text-[10px] uppercase tracking-widest font-medium">
                     <tr><th className="px-6 py-3">Staff</th><th className="px-6 py-3">Revenue</th><th className="px-6 py-3">Signups</th></tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900 text-zinc-300">
                     {staff.map((s, i) => (
                        <tr key={i} className="hover:bg-zinc-900/50 transition-colors">
                           <td className="px-6 py-4 flex items-center gap-3">
                              {i === 0 && <Crown className="w-3 h-3 text-luxury-gold" />}
                              <span className="font-serif">{s.name}</span> <span className="text-xs text-zinc-600">/ {s.role}</span>
                           </td>
                           <td className="px-6 py-4 font-bold text-white font-mono">${s.revenue.toLocaleString()}</td>
                           <td className="px-6 py-4 text-zinc-400">{s.signups}</td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </CardContent>
         </Card>

         {/* Inventory Insights */}
         <Card className="border-zinc-900 bg-zinc-950 shadow-none">
            <CardHeader className="border-zinc-900 pb-2">
               <CardTitle className="text-white font-serif">Inventory Movers</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
               <table className="w-full text-left text-sm">
                  <thead className="bg-zinc-900/30 text-zinc-500 text-[10px] uppercase tracking-widest font-medium">
                     <tr><th className="px-6 py-3">Item</th><th className="px-6 py-3">Vol</th><th className="px-6 py-3">Trend</th><th className="px-6 py-3">Action</th></tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-900 text-zinc-300">
                     {inventory.map((item, i) => (
                        <tr key={i} className="hover:bg-zinc-900/50 transition-colors">
                           <td className="px-6 py-4">
                              <span className="font-serif text-white">{item.name}</span>
                              <div className="text-[10px] text-zinc-500 uppercase">{item.category}</div>
                           </td>
                           <td className="px-6 py-4 font-mono">{item.salesVolume}</td>
                           <td className="px-6 py-4">
                              {item.trend === 'up' 
                                 ? <span className="text-luxury-gold flex items-center gap-1 text-xs"><ArrowUpRight className="w-3 h-3"/> Up</span> 
                                 : <span className="text-zinc-600 flex items-center gap-1 text-xs"><ArrowDownRight className="w-3 h-3"/> Down</span>
                              }
                           </td>
                           <td className="px-6 py-4">
                              {item.action !== 'None' && (
                                 <span className="px-2 py-1 bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-300 uppercase tracking-wide">
                                    {item.action}
                                 </span>
                              )}
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </CardContent>
         </Card>
      </div>
    </div>
  );
};

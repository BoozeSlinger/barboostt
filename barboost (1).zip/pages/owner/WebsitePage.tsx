
import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { WebsiteStats } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Globe, ArrowUpRight, Smartphone, Laptop, Users, Eye, MousePointer } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

export const WebsitePage: React.FC = () => {
  const { user } = useContext(AuthContext);
  const [stats, setStats] = useState<WebsiteStats | null>(null);

  useEffect(() => {
    if (user?.barId) {
      mockService.getWebsiteStats(user.barId).then(setStats);
    }
  }, [user]);

  if (!stats) return <div className="text-slate-500">Loading website analytics...</div>;

  const COLORS = ['#22d3ee', '#3b82f6', '#f472b6', '#94a3b8'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
            <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                <Globe className="w-6 h-6 text-neon-blue" />
            </div>
            <div>
                <h2 className="text-xl font-bold text-white">Website Traffic</h2>
                <p className="text-xs text-slate-500">Data updated monthly by Admin • Last update: {stats.lastUpdated}</p>
            </div>
        </div>
      </div>

      {/* Main Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-bg-card border-slate-800">
            <CardContent className="p-6">
                <div className="flex justify-between items-start">
                    <p className="text-sm font-medium text-slate-400">Total Visitors</p>
                    <Users className="w-4 h-4 text-neon-cyan" />
                </div>
                <div className="mt-2 flex items-baseline gap-2">
                    <h3 className="text-2xl font-bold text-white">{stats.visits.toLocaleString()}</h3>
                    <span className="text-xs font-bold text-neon-green flex items-center">
                        <ArrowUpRight className="w-3 h-3" /> {stats.visitsGrowth}%
                    </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">vs last month</p>
            </CardContent>
        </Card>

        <Card className="bg-bg-card border-slate-800">
            <CardContent className="p-6">
                <div className="flex justify-between items-start">
                    <p className="text-sm font-medium text-slate-400">Page Views</p>
                    <Eye className="w-4 h-4 text-neon-purple" />
                </div>
                <div className="mt-2">
                    <h3 className="text-2xl font-bold text-white">{stats.pageViews.toLocaleString()}</h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">Avg 2.9 pages/session</p>
            </CardContent>
        </Card>

        <Card className="bg-bg-card border-slate-800">
            <CardContent className="p-6">
                <div className="flex justify-between items-start">
                    <p className="text-sm font-medium text-slate-400">Bounce Rate</p>
                    <MousePointer className="w-4 h-4 text-neon-orange" />
                </div>
                <div className="mt-2">
                    <h3 className="text-2xl font-bold text-white">{stats.bounceRate}%</h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">Lower is better</p>
            </CardContent>
        </Card>

        <Card className="bg-bg-card border-slate-800">
            <CardContent className="p-6">
                <div className="flex justify-between items-start">
                    <p className="text-sm font-medium text-slate-400">Avg Time on Site</p>
                    <Globe className="w-4 h-4 text-neon-green" />
                </div>
                <div className="mt-2">
                    <h3 className="text-2xl font-bold text-white">{stats.avgTimeOnSite}</h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">Industry avg: 1m 30s</p>
            </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-bg-card border-slate-800">
            <CardHeader className="border-slate-800">
                <CardTitle className="text-white">Traffic Sources</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="w-48 h-48">
                    <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                            <Pie
                                data={stats.topSources}
                                cx="50%"
                                cy="50%"
                                innerRadius={40}
                                outerRadius={80}
                                paddingAngle={5}
                                dataKey="percentage"
                                stroke="none"
                            >
                                {stats.topSources.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip 
                                contentStyle={{backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc', borderRadius: '8px'}}
                                itemStyle={{color: '#f8fafc'}}
                            />
                        </PieChart>
                    </ResponsiveContainer>
                </div>
                <div className="flex-1 space-y-3">
                    {stats.topSources.map((source, index) => (
                        <div key={index} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index] }}></div>
                                <span className="text-sm text-slate-300">{source.source}</span>
                            </div>
                            <span className="text-sm font-bold text-white">{source.percentage}%</span>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>

        <Card className="bg-bg-card border-slate-800">
            <CardHeader className="border-slate-800">
                <CardTitle className="text-white">Device Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="space-y-6">
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                            <span className="text-slate-300 flex items-center gap-2"><Smartphone className="w-4 h-4" /> Mobile</span>
                            <span className="text-white font-bold">68%</span>
                        </div>
                        <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-neon-blue rounded-full" style={{ width: '68%' }}></div>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                            <span className="text-slate-300 flex items-center gap-2"><Laptop className="w-4 h-4" /> Desktop</span>
                            <span className="text-white font-bold">25%</span>
                        </div>
                        <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-neon-purple rounded-full" style={{ width: '25%' }}></div>
                        </div>
                    </div>
                    <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                            <span className="text-slate-300 flex items-center gap-2"><Globe className="w-4 h-4" /> Tablet</span>
                            <span className="text-white font-bold">7%</span>
                        </div>
                        <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-neon-cyan rounded-full" style={{ width: '7%' }}></div>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
      </div>
    </div>
  );
};

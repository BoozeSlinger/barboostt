
import React, { useContext, useState, useEffect } from 'react';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { SalesImportBatch, SalesForecast, HourlyComparison } from '../../types';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Upload, FileText, CheckCircle2, ArrowRight, RefreshCw, Calendar, Sparkles, TrendingUp, Clock, CloudRain } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

enum UploadStep {
  UPLOAD = 1,
  PREVIEW = 2,
  PROCESSING = 3,
  RESULTS = 4
}

export const SalesPage: React.FC = () => {
  const { user } = useContext(AuthContext);
  const [forecast, setForecast] = useState<SalesForecast | null>(null);
  const [hourlyData, setHourlyData] = useState<HourlyComparison[]>([]);
  const [step, setStep] = useState<UploadStep>(UploadStep.UPLOAD);
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<SalesImportBatch | null>(null);
  const [history, setHistory] = useState<SalesImportBatch[]>([]);

  useEffect(() => {
    if (user?.barId) {
      mockService.getSalesForecast(user.barId).then(setForecast);
      mockService.getHourlySalesComparison(user.barId).then(setHourlyData);
      mockService.getImportBatches(user.barId).then(setHistory);
    }
  }, [user]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStep(UploadStep.PREVIEW);
    }
  };

  const handleProcess = async () => {
    if (!user?.barId || !file) return;
    setStep(UploadStep.PROCESSING);
    try {
      const res = await mockService.uploadSalesCsv(user.barId, file);
      setResult(res);
      setHistory(prev => [res, ...prev]);
      setStep(UploadStep.RESULTS);
    } catch (e) {
      alert("Error processing file");
      setStep(UploadStep.UPLOAD);
    }
  };

  const reset = () => {
    setFile(null);
    setResult(null);
    setStep(UploadStep.UPLOAD);
  };

  if (!forecast) return <div className="text-zinc-500 font-light">Loading sales intelligence...</div>;

  const pacePercent = Math.round((forecast.currentWeeklyPace / forecast.targetWeeklyPace) * 100);
  const isOnTrack = pacePercent >= 100;

  return (
    <div className="space-y-8 pb-10">
      
      {/* HEADER: Sales Velocity Indicators */}
      <div>
        <h2 className="text-2xl font-serif text-white mb-6">Revenue Intelligence</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-zinc-900 border border-zinc-900">
            
            {/* Sales Pace Widget */}
            <div className={`relative bg-zinc-950 p-6 group`}>
                <div className="absolute top-0 right-0 p-1 bg-luxury-gold text-black text-[10px] font-bold uppercase tracking-widest">Pace</div>
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Weekly Pace</p>
                <div className="flex items-end justify-between">
                    <h3 className={`text-3xl font-serif ${isOnTrack ? 'text-luxury-gold' : 'text-white'}`}>
                        ${forecast.currentWeeklyPace.toLocaleString()}
                    </h3>
                </div>
                <div className="text-[10px] text-zinc-500 mt-2 font-mono">
                        Target: ${forecast.targetWeeklyPace.toLocaleString()}
                </div>
                <p className="text-[10px] text-zinc-600 mt-1 italic">
                    {isOnTrack ? 'Ahead of schedule' : 'Needs attention'}
                </p>
                <div className={`absolute bottom-0 left-0 h-0.5 ${isOnTrack ? 'bg-luxury-gold' : 'bg-zinc-700'}`} style={{ width: `${Math.min(pacePercent, 100)}%` }}></div>
            </div>

            {/* Yesterday Performance */}
            <div className="bg-zinc-950 p-6">
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Yesterday</p>
                <div className="flex items-end gap-2">
                    <h3 className="text-3xl font-serif text-white">${forecast.yesterdayTotal.toLocaleString()}</h3>
                    <span className={`text-xs font-bold mb-1 ${forecast.yesterdayGrowth >= 0 ? 'text-luxury-gold' : 'text-red-400'}`}>
                        {forecast.yesterdayGrowth >= 0 ? '↑' : '↓'} {forecast.yesterdayGrowth}%
                    </span>
                </div>
                <p className="text-[10px] text-zinc-600 mt-2">vs same day last week</p>
            </div>

             {/* Best Day */}
             <div className="bg-zinc-950 p-6">
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Best Day</p>
                <div className="flex items-end gap-2">
                    <h3 className="text-3xl font-serif text-white">{forecast.bestDayThisWeek.day}</h3>
                </div>
                <p className="text-[10px] text-zinc-600 mt-2">High: <span className="text-zinc-300 font-mono">${forecast.bestDayThisWeek.amount.toLocaleString()}</span></p>
            </div>

            {/* Avg Daily Rate */}
            <div className="bg-zinc-950 p-6">
                <p className="text-zinc-500 text-[10px] font-bold uppercase tracking-[0.2em] mb-4">Avg Daily Rate</p>
                <div className="flex items-end gap-2">
                    <h3 className="text-3xl font-serif text-white">${forecast.avgDailyRate.toLocaleString()}</h3>
                </div>
                <p className="text-[10px] text-zinc-600 mt-2">Rolling 30-day average</p>
            </div>
        </div>
      </div>

      {/* ROW 2: Charts & Forecasts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Hourly Comparison Chart */}
          <Card className="lg:col-span-2 bg-zinc-950 border-zinc-900 shadow-none">
            <CardHeader className="border-zinc-900 flex flex-row items-center justify-between">
                <CardTitle className="text-white font-serif flex items-center gap-2">
                    <Clock className="w-4 h-4 text-luxury-gold" /> Hourly Performance
                </CardTitle>
                <span className="text-[10px] uppercase tracking-widest text-zinc-500">Today vs Avg Thursday</span>
            </CardHeader>
            <CardContent className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={hourlyData}>
                        <defs>
                            <linearGradient id="colorToday" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3}/>
                                <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                        <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 10}} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#52525b', fontSize: 10}} prefix="$" />
                        <Tooltip 
                            contentStyle={{backgroundColor: '#000', borderColor: '#27272a', color: '#fff', borderRadius: '0px', fontFamily: 'serif'}}
                        />
                        <Area type="monotone" dataKey="today" name="Today" stroke="#D4AF37" strokeWidth={2} fillOpacity={1} fill="url(#colorToday)" />
                        <Area type="monotone" dataKey="average" name="Avg Thursday" stroke="#52525b" strokeWidth={1} strokeDasharray="4 4" fill="none" />
                        <Legend wrapperStyle={{ fontSize: '10px', textTransform: 'uppercase', color: '#71717a' }}/>
                    </AreaChart>
                </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Weekend Forecast & AI Insights */}
          <div className="space-y-6">
              {/* Weekend Forecast */}
              <Card className="bg-zinc-950 border-zinc-900 shadow-none">
                  <CardContent className="p-8 text-center">
                      <div className="flex justify-center items-center gap-2 mb-6">
                          <Calendar className="w-5 h-5 text-luxury-gold" />
                          <h3 className="font-serif text-white text-lg">Weekend Forecast</h3>
                      </div>
                      <div className="py-6 border-y border-zinc-900">
                          <p className="text-[10px] text-zinc-500 uppercase tracking-widest mb-2">Projected Revenue</p>
                          <p className="text-4xl font-serif text-luxury-gold">${forecast.weekendForecast.toLocaleString()}</p>
                      </div>
                      <p className="text-xs text-zinc-600 mt-6 font-light">
                          AI Model confidence: <span className="text-zinc-400">High (92%)</span>
                      </p>
                  </CardContent>
              </Card>

              {/* AI Insights */}
              <Card className="bg-gradient-to-br from-zinc-900 to-black border-zinc-900 shadow-none">
                  <CardHeader className="border-zinc-900 pb-2">
                      <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-luxury-gold" />
                          <CardTitle className="text-white text-sm font-serif">Analysis</CardTitle>
                      </div>
                  </CardHeader>
                  <CardContent className="space-y-4 pt-4">
                      {forecast.aiInsights.map((insight, i) => (
                          <div key={i} className="flex gap-3 text-xs">
                              <div className="mt-1.5 w-1 h-1 rounded-full bg-luxury-gold shrink-0"></div>
                              <p className="text-zinc-400 font-light leading-relaxed">{insight}</p>
                          </div>
                      ))}
                  </CardContent>
              </Card>
          </div>
      </div>

      <hr className="border-zinc-900 my-8" />

      {/* BOTTOM SECTION: DATA MANAGEMENT (Import CSV) */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
            <h2 className="text-xl font-serif text-white">Data Management</h2>
            <Button variant="outline" size="sm" className="bg-transparent border-zinc-800 text-zinc-400 hover:text-white uppercase tracking-widest text-xs">Download Template</Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
            <Card className="bg-zinc-950 border-zinc-900 shadow-none">
                <CardHeader className="border-b border-zinc-900 py-4">
                <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest text-zinc-600">
                    <span className={step === 1 ? 'text-luxury-gold' : ''}>1. Upload POS CSV</span>
                    <ArrowRight className="w-3 h-3" />
                    <span className={step >= 2 ? 'text-luxury-gold' : ''}>2. Review & Process</span>
                </div>
                </CardHeader>
                <CardContent className="p-8">
                {step === UploadStep.UPLOAD && (
                    <div className="border border-dashed border-zinc-800 rounded-sm p-12 flex flex-col items-center justify-center space-y-6 bg-black hover:bg-zinc-900/30 transition-colors">
                        <Upload className="w-10 h-10 text-zinc-700" />
                        <div className="text-center">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Import POS Data</h3>
                            <p className="text-zinc-600 text-xs mt-2">Supports Toast, Square, Clover</p>
                        </div>
                        <input type="file" accept=".csv" onChange={handleFileChange} className="hidden" id="csv-upload" />
                        <label htmlFor="csv-upload" className="cursor-pointer">
                            <div className="bg-white text-black px-6 py-2 rounded-sm text-xs font-bold uppercase tracking-widest hover:bg-luxury-gold transition-colors">Select CSV</div>
                        </label>
                    </div>
                )}

                {step === UploadStep.PREVIEW && file && (
                    <div className="space-y-6">
                        <div className="flex items-center justify-between bg-black p-4 border border-zinc-900">
                            <div className="flex items-center gap-3">
                                <FileText className="w-5 h-5 text-luxury-gold" />
                                <p className="font-mono text-zinc-300 text-sm">{file.name}</p>
                            </div>
                            <button onClick={reset} className="text-xs text-red-900 hover:text-red-500 uppercase tracking-wider">Remove</button>
                        </div>
                        <div className="flex justify-end gap-2">
                            <Button size="sm" onClick={handleProcess} className="bg-luxury-gold text-black hover:bg-white font-bold uppercase tracking-widest text-xs rounded-sm">Process Import</Button>
                        </div>
                    </div>
                )}

                {step === UploadStep.PROCESSING && (
                    <div className="text-center py-12">
                        <RefreshCw className="w-8 h-8 text-luxury-gold animate-spin mx-auto mb-4" />
                        <p className="text-white text-sm font-light tracking-wide">Matching customer records...</p>
                    </div>
                )}

                {step === UploadStep.RESULTS && result && (
                    <div className="text-center space-y-6 py-4">
                        <div className="inline-flex p-4 bg-green-900/10 rounded-full text-green-500 border border-green-900/30">
                            <CheckCircle2 className="w-8 h-8" />
                        </div>
                        <div>
                            <h3 className="font-serif text-white text-xl mb-2">Import Complete</h3>
                            <p className="text-sm text-zinc-500">Matched <span className="text-white">{result.matchedRows}</span> of {result.totalRows} transactions.</p>
                        </div>
                        <Button size="sm" onClick={reset} className="bg-zinc-900 text-white border border-zinc-800 hover:bg-zinc-800 w-full rounded-sm uppercase tracking-widest text-xs">Upload Another</Button>
                    </div>
                )}
                </CardContent>
            </Card>
            </div>

            {/* Import History Side Panel */}
            <div className="bg-zinc-950 border border-zinc-900 h-fit">
                <div className="p-4 border-b border-zinc-900 bg-zinc-900/30">
                    <h3 className="font-bold text-white text-xs uppercase tracking-widest">Recent Imports</h3>
                </div>
                <div className="divide-y divide-zinc-900">
                    {history.length === 0 ? <p className="p-4 text-xs text-zinc-600 italic">No history available</p> : 
                    history.slice(0, 3).map(batch => (
                        <div key={batch.id} className="p-4 hover:bg-zinc-900/30 transition-colors">
                            <div className="flex justify-between items-start mb-1">
                                <p className="font-mono text-zinc-300 text-xs truncate max-w-[120px]">{batch.filename}</p>
                                <span className="text-[10px] text-green-500 border border-green-900/30 px-1.5 py-0.5 uppercase">Success</span>
                            </div>
                            <p className="text-[10px] text-zinc-600 mt-1">
                                {new Date(batch.importDate).toLocaleDateString()} • <span className="text-zinc-500">${batch.totalRevenue.toLocaleString()}</span>
                            </p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

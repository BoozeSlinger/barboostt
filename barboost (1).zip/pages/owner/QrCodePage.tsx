
import React, { useContext } from 'react';
import { AuthContext } from '../../App';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Download, Copy, ExternalLink, FileJson, Image as ImageIcon } from 'lucide-react';

export const QrCodePage: React.FC = () => {
  const { user } = useContext(AuthContext);
  
  const barSlug = 'rusty-anchor'; // Mock slug
  const signupUrl = `${window.location.origin}/#/signup/${barSlug}`;
  
  // API URLs for different formats
  const baseApi = 'https://api.qrserver.com/v1/create-qr-code/';
  const dataParam = `data=${encodeURIComponent(signupUrl)}`;
  const displayUrl = `${baseApi}?size=300x300&${dataParam}&color=000000&bgcolor=FFFFFF&margin=10`;
  const highResUrl = `${baseApi}?size=1000x1000&${dataParam}&color=000000&bgcolor=FFFFFF&margin=0`;
  const svgUrl = `${baseApi}?size=1000x1000&${dataParam}&format=svg&color=000000&bgcolor=FFFFFF&margin=0`;

  const handleCopy = () => {
    navigator.clipboard.writeText(signupUrl);
    // In a real app we'd use a toast, alert is fine for now
    alert('URL copied to clipboard!');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
          <h2 className="text-2xl font-serif text-white">Acquisition Points</h2>
      </div>

      <Card className="bg-zinc-950 border-zinc-900 shadow-none">
        <CardContent className="p-10 flex flex-col md:flex-row items-center gap-12">
          {/* QR Container - Gold Frame */}
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-tr from-luxury-gold to-yellow-100 opacity-30 blur-lg rounded-xl group-hover:opacity-50 transition-opacity duration-700"></div>
            <div className="relative bg-white p-6 rounded-sm border border-zinc-200">
              <img src={displayUrl} alt="Bar Signup QR Code" className="w-64 h-64 object-contain mix-blend-multiply" />
            </div>
          </div>
          
          <div className="flex-1 space-y-8 text-center md:text-left">
            <div>
              <h2 className="text-3xl font-serif text-white mb-3">VIP Access Point</h2>
              <p className="text-zinc-400 font-light leading-relaxed">
                Deploy this unique code on table tents, menus, and signage. When guests scan, they enter your owned audience ecosystem instantly.
              </p>
            </div>

            <div className="p-4 bg-black rounded-sm border border-zinc-900 font-mono text-xs text-luxury-gold break-all shadow-inner">
              {signupUrl}
            </div>

            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              <div className="flex flex-col gap-2">
                 <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Downloads</p>
                 <div className="flex gap-3">
                    <Button onClick={() => window.open(highResUrl, '_blank')} className="bg-luxury-gold text-black hover:bg-white hover:text-black font-bold uppercase tracking-widest text-xs rounded-sm">
                        <ImageIcon className="w-4 h-4 mr-2" />
                        High-Res PNG
                    </Button>
                    <Button onClick={() => window.open(svgUrl, '_blank')} className="bg-zinc-900 text-white border border-zinc-800 hover:border-luxury-gold hover:text-luxury-gold uppercase tracking-widest text-xs rounded-sm">
                        <FileJson className="w-4 h-4 mr-2" />
                        Vector SVG
                    </Button>
                 </div>
              </div>
              
              <div className="w-px bg-zinc-900 hidden md:block mx-2"></div>

              <div className="flex flex-col gap-2">
                 <p className="text-[10px] uppercase tracking-widest text-zinc-500 font-bold">Actions</p>
                 <div className="flex gap-3">
                    <Button variant="outline" onClick={handleCopy} className="bg-transparent border-zinc-800 text-zinc-400 hover:text-white hover:border-white uppercase tracking-widest text-xs rounded-sm">
                        <Copy className="w-4 h-4 mr-2" />
                        Copy URL
                    </Button>
                    <Button variant="outline" onClick={() => window.open(signupUrl, '_blank')} className="bg-transparent border-zinc-800 text-zinc-400 hover:text-white hover:border-white uppercase tracking-widest text-xs rounded-sm">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Test
                    </Button>
                 </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-zinc-950 border-zinc-900 shadow-none">
          <CardContent className="p-8">
            <h3 className="font-serif text-white text-lg mb-4">Placement Strategy</h3>
            <ul className="space-y-3">
              {[
                  "Table Tents: High visibility, high conversion.",
                  "Check Presenters: Capture guests as they leave.",
                  "Bathroom Mirrors: Surprise and delight placement.",
                  "Host Stand: 'Join for waitlist updates'."
              ].map((tip, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-zinc-400 font-light">
                      <div className="w-1.5 h-1.5 rounded-full bg-luxury-gold mt-1.5 shrink-0"></div>
                      {tip}
                  </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};


import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../App';
import { mockService } from '../../services/mockService';
import { Campaign, CampaignType } from '../../types';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Plus, Mail, MessageSquare } from 'lucide-react';

interface CampaignsPageProps {
  defaultType: CampaignType; // 'sms' or 'email'
}

export const CampaignsPage: React.FC<CampaignsPageProps> = ({ defaultType }) => {
  const { user } = useContext(AuthContext);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(false);

  // New Campaign Form State
  const [formData, setFormData] = useState({
    name: '',
    type: defaultType,
    subject: '',
    message: '',
  });

  // Reset form type when route changes
  useEffect(() => {
    setFormData(prev => ({ ...prev, type: defaultType }));
    setIsCreating(false);
  }, [defaultType]);

  useEffect(() => {
    if (user?.barId) {
      mockService.getCampaigns(user.barId).then((data) => {
        // Filter campaigns based on the current page type
        // Note: We include 'both' in both lists, or strictly filter. 
        // Showing 'both' in both lists is usually better UX.
        const filtered = data.filter(c => c.type === defaultType || c.type === 'both');
        setCampaigns(filtered);
      });
    }
  }, [user, isCreating, defaultType]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user?.barId) return;
    setLoading(true);
    
    await mockService.createCampaign({
      barId: user.barId,
      name: formData.name,
      type: defaultType, // Enforce the current type
      subject: formData.subject,
      message: formData.message,
    });
    
    setLoading(false);
    setIsCreating(false);
    // Reset form
    setFormData({ name: '', type: defaultType, subject: '', message: '' });
  };

  const isEmail = defaultType === 'email';

  if (isCreating) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white">New {isEmail ? 'Email' : 'SMS'} Campaign</h2>
          <Button variant="secondary" onClick={() => setIsCreating(false)} className="bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700">Cancel</Button>
        </div>
        <Card className="bg-bg-card border-slate-800">
          <CardContent>
            <form onSubmit={handleCreate} className="space-y-6">
              <Input
                label="Campaign Name"
                placeholder={`e.g., Friday Night ${isEmail ? 'Newsletter' : 'Promo'}`}
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                required
                className="bg-slate-900 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
              />
              
              {/* Type selection hidden, implied by page */}
              <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg flex items-center gap-3 text-slate-400">
                {isEmail ? <Mail className="w-5 h-5 text-neon-purple" /> : <MessageSquare className="w-5 h-5 text-neon-blue" />}
                <span className="text-sm font-medium">Sending via {isEmail ? 'Email' : 'SMS'}</span>
              </div>

              {isEmail && (
                <Input
                  label="Subject Line"
                  placeholder="Don't miss out..."
                  value={formData.subject}
                  onChange={e => setFormData({...formData, subject: e.target.value})}
                  required
                  className="bg-slate-900 border-slate-800 text-white placeholder-slate-600 focus:border-neon-blue"
                />
              )}

              <div className="space-y-1">
                <label className="text-sm font-medium text-slate-400">Message</label>
                <textarea
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-md focus:outline-none focus:ring-1 focus:ring-neon-blue focus:border-neon-blue min-h-[120px] text-white placeholder-slate-600"
                  placeholder={`Type your ${isEmail ? 'email content' : 'text message'} here...`}
                  value={formData.message}
                  onChange={e => setFormData({...formData, message: e.target.value})}
                  required
                />
                <p className="text-xs text-slate-500 text-right">{formData.message.length} characters</p>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <Button type="submit" isLoading={loading} className="bg-neon-blue hover:bg-neon-blue/80 text-white">
                  Schedule {isEmail ? 'Email' : 'SMS'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">{isEmail ? 'Email' : 'SMS'} Campaigns</h2>
        <Button onClick={() => setIsCreating(true)} className="bg-neon-blue hover:bg-neon-blue/80 text-white">
          <Plus className="w-4 h-4 mr-2" />
          Create {isEmail ? 'Email' : 'SMS'}
        </Button>
      </div>

      <div className="grid gap-4">
        {campaigns.length === 0 ? (
          <div className="text-center py-12 bg-bg-card rounded-xl border border-dashed border-slate-800">
            <p className="text-slate-500">No {isEmail ? 'email' : 'SMS'} campaigns found.</p>
          </div>
        ) : (
          campaigns.map((campaign) => (
            <Card key={campaign.id} className="bg-bg-card border-slate-800 hover:border-slate-700 transition-colors">
              <div className="p-6 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="font-semibold text-slate-200">{campaign.name}</h3>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium capitalize 
                      ${campaign.status === 'sent' ? 'bg-green-900/30 text-green-400 border border-green-900' : 
                        campaign.status === 'scheduled' ? 'bg-blue-900/30 text-blue-400 border border-blue-900' : 'bg-slate-800 text-slate-400 border border-slate-700'}`}>
                      {campaign.status}
                    </span>
                    {/* Show icon to distinguish 'both' type if present in list */}
                    {campaign.type === 'both' && (
                      <span className="text-xs text-slate-500 border border-slate-700 px-1.5 rounded">Both</span>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 truncate max-w-lg">{campaign.message}</p>
                </div>
                <div className="text-right text-sm">
                  <p className="font-medium text-slate-300">{campaign.recipientCount} Recipients</p>
                  <p className="text-slate-500">
                    {campaign.sentAt ? new Date(campaign.sentAt).toLocaleDateString() : 'Scheduled'}
                  </p>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
